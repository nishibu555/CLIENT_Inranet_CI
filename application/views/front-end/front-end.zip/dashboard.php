<div class="container">
    <div class="row">
        <div class="col">
            <div class="sub_nav">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active"><a href="#">Home</a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="side_div1">
                <div class="headingside_div1">
                    <h5>MESSAGE BOARD <i class="fas fa-comment"></i></h5>
                </div>
                <img src="<?php base_url()?>assets/images/icon_records.png" class="img-fluid">

            </div>

        </div>

        <div class="col-md-8">
            <div class="row">
                <div class="col-md-6 board-list">
                    <div class="dashboard-icon">
                        <img src="<?php echo base_url()?>assets/images/icon_records.png" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>Records</h3>
                        <ul>
                            <li><span>Quick Links:</span></li>
                            <li><a href="<?php echo base_url()?>academic">Academics</a></li>
                            <li><a href="<?php echo base_url()?>activity-log">Activity Log</a></li>
                            <li><a href="#">Bed Assignment</a></li>
                            <li><a href="#">Chronological</a></li>
                            <li><a href="#">Development Plans</a></li>
                            <li><a href="#">Discipline</a></li>
                            <li><a href="#">Education Log</a></li>
                            <li><a href="#">Staff Correction</a></li>
                            <li><a href="<?php echo base_url()?>student_manager">Student Manager</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6 board-list">
                    <div class="dashboard-icon">
                        <img src="<?php echo base_url()?>assets/images/icon_office.png" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>Office</h3>
                    </div>
                </div>
                <div class="col-md-6 board-list">
                    <div class="dashboard-icon">
                        <img src="<?php echo base_url()?>assets/images/icon_marketing.png" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>Marketing</h3>
                    </div>
                </div>
                <div class="col-md-6 board-list">
                    <div class="dashboard-icon">
                        <img src="<?php echo base_url()?>assets/images/work.png" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>Work Crews</h3>
                    </div>
                </div>
                <div class="col-md-6 board-list">
                    <div class="dashboard-icon">
                        <img src="<?php echo base_url()?>assets/images/ionic_setting.png" class="img-fluid">
                    </div>
                    <div class="content">
                        <h3>Settings</h3>
                    </div>
                </div>
            </div>
        </div>
    </div><!--row-->
</div>
