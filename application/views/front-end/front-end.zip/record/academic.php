<div class="container">
    <div class="row">
        <div class="col">
            <div class="sub_nav">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active" ><a href="#">Records</a></li>
                        <li class="breadcrumb-item active" ><a href="#">Students Manager</a></li>
                        <li class="breadcrumb-item active" ><a href="#">Academics</a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="side_div1">
                <p>RECORDS</p>
                <img style="width: 100%;" src="<?php base_url()?>assets/images/icon_records.png">
            </div>

        </div>

        <div class="col-md-9">
            <div class="student_academic_history">
                <div class="table_title" style="margin-top: 30px;">
                    <h5>Student Manager:</h5>
                </div>
                <div class="student_academic">
                    <p style="margin-top: 6px">ACADEMICS</p>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Student Name</th>
                                <th scope="col">Entry Date</th>
                                <th scope="col">Phase</th>
                                <th scope="col">GSNC</th>
                                <th scope="col">PSNC</th>
                                <th scope="col">Counselor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($students as $student){?>
                                <tr>
                                    <td>
                                        <img src="<?php base_url()?>assets/images/student.png">
                                        <ul>
                                            <li><a class="std_name" href="<?php echo base_url()?>students_gsnc_psnc/<?php echo $student['student_id']?>"><?php echo $student['first_name'].','.$student['last_name']?></a></li>
                                            <li><a class="std-contract" href="#">&#8226; Contract is late</a></li>
                                        </ul>
                                    </td>
                                    <td><?php echo date("m-d-y", strtotime($student['created_at']))?></td>
                                    <td>0</td>
                                    <td>0</td>
                                    <td>0</td>
                                    <td></td>
                                </tr>

                            <?php }?>
                        </tbody>
                    </table>
                    <a href="<?php echo base_url()?>student-test-score" class="btn btn-primary score-btn">Add New Score</a>
                </div>
            </div>
        </div><!--row-->
    </div>
