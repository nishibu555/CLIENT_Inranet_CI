
 <div class="container">
  <div class="row">
  <div class="col">
  <div class="sub_nav">
  <nav aria-label="breadcrumb">
 <ol class="breadcrumb">
   <li class="breadcrumb-item active"><a href="<?= base_url()?>">Home</a></li>
   <li class="breadcrumb-item active" ><a href="<?= base_url('records')?>">Records</a></li>
   <li class="breadcrumb-item active" ><a href="<?= base_url('student_manager')?>">Student manager</a></li>
 </ol>
</nav>
  </div>
  </div>
  </div>
  <div class="row">
<div class="col-md-4">
<div class="side_div1">
<p>STUDENT MANAGER</p>
<i class="fas fa-user-graduate"></i>
</div>

<div class="side_div1">
<p>INCOMING STUDENTS</p>
<div style="margin: 5% 10%">
<small class="side_div1_text">It is a long established fact that a reader will be distracted</small>
<div style="margin: 30px 0px;">
<select id="incoming_student">
 <option value="">Select an applicant</option>
 <?php foreach ($incoming_student as $incoming_student) { ?>
    <option value="<?php echo base_url()."incoming_student_detail/".$incoming_student->student_id ?>"><?php echo $incoming_student->first_name."".$incoming_student->last_name ?></option>
 <?php } ?>
</select>
</div>
</div>
</div>

<div class="side_div2">
<div class="inner_side_div2">
<p>Manually add new student bellow</p>
<form  class="new_student_form1" id="manual_add_form" >
<input type="text" name="first_name" placeholder="Fisrt Name">
<input type="text" name="last_name" placeholder="Last Name">
<span><?php echo validation_errors();?></span>
<button type="submit" class="btn btn-primary submit_button">Add Student</button>

   </form>
</div>
</div>

<div class="side_div1">
<p>STUDENTS ARCHIVE</p>
<div style="margin: 5% 10%">
<small class="side_div1_text">It is a long established fact that a reader will be distracted</small>
<div style="margin: 30px 0px;">
  <select id="std_archive">
 <option value="">-- select one --</option>
                        <?php foreach($archive_student as $student):?>
 <option value="<?= base_url('student_detail'.'/'.$student->student_id)?>"><?= $student->first_name.' '.$student->middle_name.' '.$student->last_name?></option>
                        <?php endforeach;?>
</select>
</div>
</div>
</div>
</div>

<div class="col-md-8">
<div class="table_title" style="margin-top: 30px">
<h5>STUDENTS MANAGER</h5>
</div>
  <div style="margin-top: 10px">
  <p style="font-size: 21px; color: #3d3d3d; font-family: Arial">ACTIVE STUDENTS</p>
  </div>

<div class="table-responsive">
<table class="table studentTable">
    <thead>
        <tr>
            <th style="width:250px" colspan="2">Student name</th>
            <th>Entry date</th>
            <th>Grant date</th>
            <th>Decipline</th>
            <th>Count order</th>
            <th>Phase</th>
            <th>GSNC</th>
            <th>PSNC</th>
            <th>Counselor</th>
            <th>Recidence</th>
            <th>Action</th>
        </tr>
    </thead>
<tbody>
    <?php foreach($active_students as $value):?>
    <tr>
        <td>
        <?php if(isset($value->std_image)):?>
            <img src="<?= base_url('assets/images/'.$value->std_image)?>" style="width: 40px;">
        <?php else:?>
              <img src="<?= base_url('assets/images/default_profile.jpg')?>" style="width: 40px;">
        <?php endif;?>
         <img src="" height="40px; width: 40px">
        </td>
        <td>
            <p><a href="<?= base_url('student_detail'.'/'.$value->student_id)?>"><?= $value->first_name.' '.$value->middle_name.' '.$value->last_name?></a></p>
        <ul>
        <li>Development plan is late</li>
        </ul>
        </td>

        <td><?= date('d-m-Y',strtotime($value->created_at))?></td>
        <td><?= date('d-m-Y',strtotime($value->acceptance_date))?></td>

        <td>
        <div class="checkbox-circle">
              <input type="checkbox" name="checkbox" value="1">
           </div>
       </td>
        <td>
        <div class="checkbox-circle">
              <input type="checkbox" name="checkbox" value="1">
           </div>
       </td>

       <td><?= $value->current_phase == ''?'0': $value->current_phase?></td>
        <?php 
        $gsnc = $this->db->query("SELECT * FROM `academics_scores` WHERE `student_id`= $value->student_id ORDER BY `id` DESC")->row(); 
        if($value->counselor_id != ''){    
            $counselor = $this->db->query("SELECT * FROM `counselors` WHERE `id`= $value->counselor_id ")->row();
         } else{
            $counselor = '';}
        ?>
        
       <td><?= $gsnc == ''?'0': $gsnc->gsnc_id?></td>
       <td><?= $value->psnc == ''?'0': $value->psnc?></td>
  
       <td><?= $counselor == ''?'': $counselor->nickname?></td>
       <td>--</td>


        <td>
        <span class="pull-right edit_menu">
        <a href="<?= base_url('student_detail'.'/'.$value->student_id)?>">
        <i class="far fa-edit"></i>
        </a>
        <a data-id="<?= $value->student_id?>" class="deleteBtn" style="cursor:pointer">
        <i class="far fa-trash-alt"></i>
        </a>
        </span>
        </td>
    </tr>
    <?php endforeach;?>
</tbody>
</table>
</div>

</div>
  </div><!--row-->
 </div>

<script>
    $(document).ready(function(){

        $('#incoming_student').on('change',function(){
            var href = $( "#incoming_student option:selected" ).val();
            window.location.replace(href);
        });


        $('#std_archive').on('change',function(){
            var href = $( "#std_archive option:selected" ).val();
            window.location.replace(href);
        });
       

         
     $('#manual_add_form').on('submit',function(event){
       event.preventDefault();
       var formData =new FormData(this);
         
       $.ajax({
         url : "<?= base_url('student_manager/manual_std/store')?>",
         type : "POST",
         data: formData ,
         processData: false,
         contentType: false,
         dataType: 'json',
         success:function(data){
           if (data.error_list)
              {
                  $.each(data.error_list, function(key,val) {
                      $('.'+key).text(val).css('color','red');
                  });
              }else
              {
                   $("#form_data")[0].reset();
                   $('#addNewpage').modal('hide');
                   $('.modal-backdrop').remove();
                   $('#pageDatatable').DataTable().ajax.reload();
                   location.reload();
              }
         }
       });
      });
        //delete student 
        $('.deleteBtn').click(function(){
            var id = $(this).data('id');
            console.log(id);
        Swal.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
              if (result.value) {
             $.ajax({
                 url : "<?= base_url('delete_student')?>",
                 type : "POST",
                 data: {id:id} ,
                 dataType: 'json',
                 success:function(data){
                    Swal.fire(
                      'Deleted!',
                      'Your file has been deleted.',
                      'success'
                    )
                     location.reload();

                 }
               });
              }
            })
        });
    });
</script>