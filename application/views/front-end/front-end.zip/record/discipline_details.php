
 <div class="container">
  <div class="row">
  <div class="col">
  <div class="sub_nav">
  <nav aria-label="breadcrumb">
 <ol class="breadcrumb">
   <li class="breadcrumb-item active"><a href="<?= base_url()?>">Home</a></li>
   <li class="breadcrumb-item active" ><a href="<?= base_url('records')?>">Records</a></li>
   <li class="breadcrumb-item active" ><a href="<?= base_url('student_manager')?>">Student manager</a></li>
 </ol>
</nav>
  </div>
  </div>
  </div>
  <div class="row">
<div class="col-md-4">
<div class="side_div1">
<p>DESCIPLINE MANAGER</p>
<i class="fas fa-user-graduate"></i>
</div>
</div>

<div class="col-md-8">
      <div class="table_title" style="margin-top: 30px">
      <h5>DESCIPLINE MANAGER</h5>
      </div>
      <div style="margin-top: 10px">
      <p style="font-size: 21px; color: #3d3d3d; font-family: Arial">Kevin Carter</p>
      </div>
      <div class="table-responsive">
          <table class="table studentTable">
            <thead>
              <tr>
                <th>Discipline Status</th>
                <th>Date Submitted</th>
                <th>Date Reviewed</th>
                <th>Date Resolved</th>
              </tr>
            </thead>

            <tbody>
              <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
              </tr>
            </tbody>
          </table>
      </div>

      <div class="row" style="margin-top: 20px;">
        <div class="col-md-12">
          <div style="float: left;">
              <nav aria-label="Page navigation example">
                <ul class="pagination">
                  <li class="page-item">
                    <a class="page-link" href="#" aria-label="Previous">
                      <span aria-hidden="true" style="color:  #0f3a64;">&laquo;</span>
                      <span style="color:  #0f3a64; padding-left: 10px">previous</span>
                    </a>
                  </li>
                </ul>
              </nav>
          </div>
          <div style="float: right;">
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <a class="page-link" href="#" aria-label="Next">
                      <span style="color:  #0f3a64; padding-right: 10px " >next</span>
                      <span aria-hidden="true"style="color:  #0f3a64;" >&raquo;</span>
                    </a>
                  </li>
                </ul>
              </nav>
          </div>
        </div>
      </div>

      <div style="margin-top: 20px">
          <div class="descipline_detail_notes">
            <span>Description of Infraction</span>
            <p>on 8/17/2019  upon arriving at work site, I found Kevin and another student smoking.
              It was a Saturday and the students were not expecting a staff member to show up. 
              On 8/19/2019 I called Kevin in my office and notified him a discipline would be forth coming after speaking with 
            </p>
          </div>
          <div class="descipline_detail_notes">
            <span>Discipline Administered</span>
            <p>After long consideration It is decided to give a final warning to student for violation of smoking. Student was counseled and made aware that this was a final warning. If there is any other violation, kevin will be expelled from the program.  
            </p>
          </div>
          <div class="descipline_detail_notes">
            <span>Committee Notes</span><br>
            <i>No notes have been recorded for this discipline.</i>
          </div>
      </div>
      <?php echo $this->pagination->create_links();?>
      <div style="margin-top: 20px ">
        <div style="float: left;" >
          <button type="button" class="custom_button">Revert To Open</button>
        </div>
      </div>

  </div>
</div><!--row-->

 </div>

