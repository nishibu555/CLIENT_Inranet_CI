
 <div class="container">
  <div class="row">
  <div class="col">
  <div class="sub_nav">
  <nav aria-label="breadcrumb">
 <ol class="breadcrumb">
   <li class="breadcrumb-item active"><a href="<?= base_url()?>">Home</a></li>
   <li class="breadcrumb-item active" ><a href="<?= base_url('records')?>">Records</a></li>
   <li class="breadcrumb-item active" ><a href="<?= base_url('student_manager')?>">Student manager</a></li>
 </ol>
</nav>
  </div>
  </div>
  </div>
  <div class="row">
<div class="col-md-4">
<div class="side_div1">
<p>DESCIPLINE MANAGER</p>
<i class="fas fa-user-graduate"></i>
</div>

<div class="side_div1">
<p>WRITES-UP</p>
<div style="margin: 5% 10%">
<small class="side_div1_text">It is a long established fact that a reader will be distracted</small>
<div style="margin: 30px 0px;">
<select id="incoming_student">
 <option value="">Select an applicant</option>
 <?php foreach ($pending_student as $value) { ?>
    <?php $student = $this->db->query("SELECT * FROM `student_info` WHERE `student_id` = $value->student_id")->row(); ?>
    <option value="<?php echo base_url()."students/discipline/details/".$value->student_id ?>"><?= $student->first_name.' '.$student->last_name ?></option>
 <?php } ?>
</select>
</div>
</div>
</div>

<div class="side_div2">
<div class="inner_side_div2">
<p>New write up</p>
<small>These disciplinary infractions have been
documented and are pending review
by the disciplinary committee.</small>
</div>
</div>

<div class="side_div1">
<p>ARCHIVES</p>
<div style="margin: 5% 10%">
<small class="side_div1_text">It is a long established fact that a reader will be distracted</small>
<div style="margin: 30px 0px;">
  <select id="std_archive">
 <option value="">-- select one --</option>
<?php foreach($resolve_discipline as $value):?>
     <?php $student = $this->db->query("SELECT * FROM `student_info` WHERE `student_id` = $value->student_id")->row(); ?>
        <option value="<?php echo base_url()."students/discipline/details/".$value->student_id ?>"><?= $student->first_name.' '.$student->last_name ?></option>
 <?php endforeach;?>
</select>
</div>
</div>
</div>
</div>

<div class="col-md-8">
<div class="table_title" style="margin-top: 30px">
<h5>DESCIPLINE MANAGER</h5>
</div>
  <div style="margin-top: 10px">
  <p style="font-size: 21px; color: #3d3d3d; font-family: Arial">Students on descipline</p>
  </div>

<div class="table-responsive">
    <table class="table" style="font-size: 12px;">
      <thead>
        <tr>
          <th>#</th>
          <th>Student name</th>
          <th>Entry date</th>
          <th>Total</th>
          <th>Discipline Administered</th>
            
        </tr>
      </thead>

      <tbody>
          <?php foreach($all_datas as $value):?>
            <tr>
                <td>
                <?php if(empty($value->std_image)):?>
                    <img src="<?= base_url('assets/images/default_profile.jpg')?>" style="width: 30px;height:30px;border-radius: 5px;">
                <?php else:?>
                     <img src="<?= base_url('assets/images/'.$value->std_image)?>" style="width: 30px;height:30px;border-radius: 5px;">
                <?php endif;?>
                </td>
                <td><a href="<?= base_url('students/discipline/details/'.$value->student_id)?>"><?= $value->first_name.' '.$value->last_name ?></a></td>
                <td><?= date('d-m-Y',strtotime($value->created_at))?></td>
                <td><?= $value->status?></td>
                <td><?= $value->admin_discipline?></td>
            </tr>
        <?php endforeach; ?>
          
      </tbody>
    </table>
</div>

</div>
  </div><!--row-->
 </div>


<script>
  $(document).ready(function(){

        $('#incoming_student').on('change',function(){
            var href = $( "#incoming_student option:selected" ).val();
            window.location.replace(href);
        });
      
       $('#std_archive').on('change',function(){
            var href = $( "#std_archive option:selected" ).val();
            window.location.replace(href);
        });
  });
</script>




















