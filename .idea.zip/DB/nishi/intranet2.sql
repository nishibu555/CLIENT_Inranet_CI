-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 28, 2019 at 12:37 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `intranet2`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(255) NOT NULL,
  `activity` text NOT NULL,
  `tags` text NOT NULL,
  `activity_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `activity`, `tags`, `activity_date`) VALUES
(1, 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.', 'test tag', '2019-09-26'),
(2, 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum', 'test tag 2', '2019-09-25');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `std_abuse_history`
--

CREATE TABLE `std_abuse_history` (
  `abuse_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `is_abused` tinyint(4) NOT NULL,
  `is_family_members_abused` tinyint(4) DEFAULT NULL,
  `when_abused` tinyint(4) DEFAULT NULL,
  `who_abused` text DEFAULT NULL,
  `when_family_member_abused` text DEFAULT NULL,
  `who_abused_family_member` text DEFAULT NULL,
  `sexual_lifecycle` text NOT NULL,
  `how_recently_involved` text NOT NULL,
  `is_engaged_homosexual` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_abuse_history`
--

INSERT INTO `std_abuse_history` (`abuse_history_id`, `student_id`, `is_abused`, `is_family_members_abused`, `when_abused`, `who_abused`, `when_family_member_abused`, `who_abused_family_member`, `sexual_lifecycle`, `how_recently_involved`, `is_engaged_homosexual`) VALUES
(0, 5, 0, 0, 0, '', '', '', 'pornography', 'How recently involved?', '0'),
(0, 5, 0, 0, 0, '', '', '', 'pornography', 'How recently involved?', '0'),
(0, 5, 0, 0, 0, '', '', '', 'pornography', 'How recently involved?', '0'),
(0, 5, 0, NULL, 0, '', '', '', 'bisexual, homosexual', 's', '0'),
(0, 1, 1, 1, 0, 'z', 'z', 'z', 'prostitution', 'z', '1');

-- --------------------------------------------------------

--
-- Table structure for table `std_academic_info`
--

CREATE TABLE `std_academic_info` (
  `academic_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `highest_grade` text NOT NULL,
  `is_currently_in_education` text DEFAULT NULL,
  `school_name` text DEFAULT NULL,
  `school_city` text DEFAULT NULL,
  `school_leaving_resone` text DEFAULT NULL,
  `have_vocational_training` tinyint(4) NOT NULL,
  `kind_of_training` text DEFAULT NULL,
  `tarinig_list_id` text DEFAULT NULL,
  `can_read` text DEFAULT NULL,
  `reading_competency` text DEFAULT NULL,
  `can_write` text DEFAULT NULL,
  `writing_competency` text DEFAULT NULL,
  `future_educational_goal` text DEFAULT NULL,
  `future_vocational_training` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_academic_info`
--

INSERT INTO `std_academic_info` (`academic_id`, `student_id`, `highest_grade`, `is_currently_in_education`, `school_name`, `school_city`, `school_leaving_resone`, `have_vocational_training`, `kind_of_training`, `tarinig_list_id`, `can_read`, `reading_competency`, `can_write`, `writing_competency`, `future_educational_goal`, `future_vocational_training`) VALUES
(0, 5, 'elementary', '1', 'If Yes, Name of School', 'City:', 'If you are no longer in an education program, please explain your reason for leaving school', 1, 'If Yes, what kind?', '9', '1', 'good', '1', 'good', 'Describe your future educational goals and plans:\r\n', 'Describe your future vocational training goals and plans:\r\n'),
(0, 1, 'middle', NULL, 'v', '', '', 0, '', NULL, '0', 'pverage', '0', 'pverage', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `std_appearance`
--

CREATE TABLE `std_appearance` (
  `appearance_id` int(11) NOT NULL,
  `student_id` int(255) NOT NULL,
  `height` text DEFAULT NULL,
  `weight` text DEFAULT NULL,
  `hair_color` text DEFAULT NULL,
  `eye_color` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_appearance`
--

INSERT INTO `std_appearance` (`appearance_id`, `student_id`, `height`, `weight`, `hair_color`, `eye_color`) VALUES
(1, 1, NULL, '43', 'gfdgdf', 'gfsdgdfsg'),
(2, 2, NULL, '', '', ''),
(3, 3, NULL, '', '', ''),
(4, 1, NULL, 'aa', 'aa', 'aa');

-- --------------------------------------------------------

--
-- Table structure for table `std_children`
--

CREATE TABLE `std_children` (
  `children_id` int(11) NOT NULL,
  `children_name` text DEFAULT NULL,
  `children_age` text DEFAULT NULL,
  `children_living_place` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_children`
--

INSERT INTO `std_children` (`children_id`, `children_name`, `children_age`, `children_living_place`) VALUES
(1, 'ss', 'ss', 'ss'),
(2, 'ss', 'ss', 'ss'),
(3, 'ss', 'ss', 'ss'),
(4, 'ss', 'ss', 'ss'),
(5, 'ss', 'ss', 'ss'),
(6, 'ss', 'ss', 'ss'),
(7, 'ss', 'ss', 'ss'),
(8, 'ss', 'ss', 'ss'),
(9, '', 'ss', ''),
(10, 'z', 'z', 'z'),
(11, 'z', 'z', 'z'),
(12, 'z', 'z', 'z');

-- --------------------------------------------------------

--
-- Table structure for table `std_children_info`
--

CREATE TABLE `std_children_info` (
  `children_info_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `have_children` tinyint(4) NOT NULL,
  `children_id` text DEFAULT NULL,
  `aspects_with_children` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_children_info`
--

INSERT INTO `std_children_info` (`children_info_id`, `student_id`, `have_children`, `children_id`, `aspects_with_children`) VALUES
(1, 5, 1, '3', ''),
(2, 5, 1, '7, 8', ''),
(3, 5, 1, NULL, 'rrrrrrrrrrrr'),
(4, 5, 1, '9', 'rrrrrrrrrrrr'),
(5, 1, 1, '10, 11, 12', 'z');

-- --------------------------------------------------------

--
-- Table structure for table `std_crime_history`
--

CREATE TABLE `std_crime_history` (
  `crime_history_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `arrested_value` text DEFAULT NULL,
  `arrest_date` text DEFAULT NULL,
  `arrest_charges` text DEFAULT NULL,
  `conviction` text DEFAULT NULL,
  `arrest_sentence` text DEFAULT NULL,
  `arrest_time_in_jail` text DEFAULT NULL,
  `charge_involved` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `std_drug_history`
--

CREATE TABLE `std_drug_history` (
  `drug_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `use_alcohol` text NOT NULL,
  `use_amphetamines` text NOT NULL,
  `use_barbiturates` text NOT NULL,
  `use_heroin` text NOT NULL,
  `use_opium` text NOT NULL,
  `use_cocaine` text NOT NULL,
  `use_tobacco` text NOT NULL,
  `use_marijuana` text NOT NULL,
  `use_crack` text NOT NULL,
  `use_other` text NOT NULL,
  `use_other_specify` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `std_emergency_contact`
--

CREATE TABLE `std_emergency_contact` (
  `emergency_contact_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `emc_name` text NOT NULL,
  `emc_address_line1` text NOT NULL,
  `emc_address_line2` text DEFAULT NULL,
  `emc_city` text NOT NULL,
  `emc_state` text NOT NULL,
  `emc_zip_code` text NOT NULL,
  `emc_home_phone` text NOT NULL,
  `emc_work_phone` text DEFAULT NULL,
  `emc_relation_to_student` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_emergency_contact`
--

INSERT INTO `std_emergency_contact` (`emergency_contact_id`, `student_id`, `emc_name`, `emc_address_line1`, `emc_address_line2`, `emc_city`, `emc_state`, `emc_zip_code`, `emc_home_phone`, `emc_work_phone`, `emc_relation_to_student`) VALUES
(1, 1, 'gdfsgdsfg', 'gdsgdsf', 'gdfsgdfs', 'gfhbgfh', 'hdhdfhg', 'bfgbgfb', 'bgfbfgb', 'bfgbfg', 'bdgbgdbgfb'),
(2, 2, 's', 's', 's', 's', 's', 's', 's', '', 's'),
(3, 3, 's', 's', 's', 's', 's', 's', 's', '', 's'),
(4, 1, 'q', 'p', 'p', 'p', 'p', 'p', 'p', 'p', 'p');

-- --------------------------------------------------------

--
-- Table structure for table `std_ethnic_background`
--

CREATE TABLE `std_ethnic_background` (
  `ethnic_background_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `ethnic_background` text NOT NULL,
  `other_ethnic_background` text DEFAULT NULL,
  `is_american_citizen` tinyint(4) DEFAULT NULL,
  `american_citizen_type` text DEFAULT NULL,
  `other_citizenship` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_ethnic_background`
--

INSERT INTO `std_ethnic_background` (`ethnic_background_id`, `student_id`, `ethnic_background`, `other_ethnic_background`, `is_american_citizen`, `american_citizen_type`, `other_citizenship`) VALUES
(1, 1, 'caucasian', 'gdfgg', 1, 'native', 'gfdgdfsg'),
(2, 2, 'caucasian', '', 1, 'native', ''),
(3, 3, 'caucasian', '', 1, 'native', ''),
(4, 1, 'caucasian', '', 1, 'native', 'aa');

-- --------------------------------------------------------

--
-- Table structure for table `std_family_history`
--

CREATE TABLE `std_family_history` (
  `family_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `relationship_as_child` text NOT NULL,
  `relationship_at_present` text NOT NULL,
  `fathers_name` text NOT NULL,
  `mothers_name` text NOT NULL,
  `is_father_living` text NOT NULL,
  `fathers_age` tinyint(4) DEFAULT NULL,
  `is_mother_living` tinyint(4) NOT NULL,
  `mothers_age` tinyint(4) DEFAULT NULL,
  `parents_marital_status` text DEFAULT NULL,
  `if_married_duration` text DEFAULT NULL,
  `not_married_duration` text DEFAULT NULL,
  `marriage_rating` text DEFAULT NULL,
  `childhood_rating` text NOT NULL,
  `childhood_rating_reason` text NOT NULL,
  `not_feel_closest` text NOT NULL,
  `if_other_closest` text DEFAULT NULL,
  `last_seen_parents` text NOT NULL,
  `last_live_at_home` text NOT NULL,
  `is_adopted` text NOT NULL,
  `is_adopted_reason` text DEFAULT NULL,
  `fathers_occupation` text DEFAULT NULL,
  `mothers_occupation` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_family_history`
--

INSERT INTO `std_family_history` (`family_history_id`, `student_id`, `relationship_as_child`, `relationship_at_present`, `fathers_name`, `mothers_name`, `is_father_living`, `fathers_age`, `is_mother_living`, `mothers_age`, `parents_marital_status`, `if_married_duration`, `not_married_duration`, `marriage_rating`, `childhood_rating`, `childhood_rating_reason`, `not_feel_closest`, `if_other_closest`, `last_seen_parents`, `last_live_at_home`, `is_adopted`, `is_adopted_reason`, `fathers_occupation`, `mothers_occupation`) VALUES
(1, 3, 'very good', 'good', 'sssss', 'ssssssssssssss', '1', 0, 1, 0, '0', '', '', NULL, 'good', 'aaaaaaa', 'father', '', '222', '222', '1', '', '', ''),
(2, 3, 'very good', 'fair', 'aaa', 'aaa', '1', 0, 1, 0, '0', '', '', NULL, 'good', 'aaa', 'father', '', 'aa', 'aa', '1', '', '', ''),
(3, 3, 'very good', 'average', 'N', 'L', '1', 50, 1, 50, 'married', '2 y', '2 y', 'very happy', 'fair', 'sdsdsdaadaaa', 'other', 'vvvv', '3 y', '3 y', '0', 'dddd', 'ddd', 'ddd'),
(4, 1, 'very good', 'good', 'z', 'z', '1', 0, 1, 0, 'married', 'z', 'z', 'very happy', 'good', 'z', 'father', 'z', 'z', 'z', '1', 'z', 'z', 'z');

-- --------------------------------------------------------

--
-- Table structure for table `std_family_member`
--

CREATE TABLE `std_family_member` (
  `family_member_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `member_name` text NOT NULL,
  `member_relationship` text NOT NULL,
  `member_age` tinyint(4) NOT NULL,
  `member_residence` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_family_member`
--

INSERT INTO `std_family_member` (`family_member_id`, `student_id`, `member_name`, `member_relationship`, `member_age`, `member_residence`) VALUES
(1, 3, '', '', 0, ''),
(2, 3, 'ss', 'ss', 2, ''),
(3, 3, 'ttt', 'ttt', 1, 'tttt'),
(4, 3, 'ss', 'ss', 33, 'aa'),
(5, 3, 'ss', 'ss', 33, 'aa'),
(6, 3, 'aa', 'aa', 0, 'aa'),
(7, 3, 'ss', 'ss', 33, 'aa'),
(8, 3, 'aa', 'aa', 0, 'aa'),
(9, 1, 'z', 'z', 0, 'z'),
(10, 1, 'z', 'z', 0, 'z');

-- --------------------------------------------------------

--
-- Table structure for table `std_financial_status`
--

CREATE TABLE `std_financial_status` (
  `financial_status` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `medical` text DEFAULT NULL,
  `dental` text DEFAULT NULL,
  `eligible_for` text DEFAULT NULL,
  `if_other_eligible_for` text DEFAULT NULL,
  `have_applied_food_stamp` tinyint(4) NOT NULL,
  `where_applied` text DEFAULT NULL,
  `have_debts` text DEFAULT NULL,
  `debts_reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_financial_status`
--

INSERT INTO `std_financial_status` (`financial_status`, `student_id`, `medical`, `dental`, `eligible_for`, `if_other_eligible_for`, `have_applied_food_stamp`, `where_applied`, `have_debts`, `debts_reason`) VALUES
(1, 5, 'Medical', 'Dental', 'welfare, other income', 'Other', 0, '', '0', ''),
(2, 5, 'Medical', 'Dental', 'welfare, disability payments', 'If Other, please specify', 1, 'If Yes, where?', '1', 'Explain'),
(3, 1, '', '', NULL, '', 1, '', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `std_in_prison`
--

CREATE TABLE `std_in_prison` (
  `in_prison_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `in_prison_date` text DEFAULT NULL,
  `in_prison_institution` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `std_legal_history`
--

CREATE TABLE `std_legal_history` (
  `legal_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `teen_challenge_accepted` text DEFAULT NULL,
  `tc_by_whom` text DEFAULT NULL,
  `tc_if_other_specify` text DEFAULT NULL,
  `tc_origin_of_court` text DEFAULT NULL,
  `ul_supervision` text DEFAULT NULL,
  `method_of_reporting` text DEFAULT NULL,
  `mr_if_other_specify` text DEFAULT NULL,
  `often_report` text DEFAULT NULL,
  `how_long` text DEFAULT NULL,
  `time_left` text DEFAULT NULL,
  `parole_officer_name` text NOT NULL,
  `agency` text DEFAULT NULL,
  `address_1` text DEFAULT NULL,
  `address_2` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `state` text DEFAULT NULL,
  `zip_code` text DEFAULT NULL,
  `phone` text DEFAULT NULL,
  `pending_against` text DEFAULT NULL,
  `pa_if_other_specify` text DEFAULT NULL,
  `pa__above_explain` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_legal_history`
--

INSERT INTO `std_legal_history` (`legal_history_id`, `student_id`, `teen_challenge_accepted`, `tc_by_whom`, `tc_if_other_specify`, `tc_origin_of_court`, `ul_supervision`, `method_of_reporting`, `mr_if_other_specify`, `often_report`, `how_long`, `time_left`, `parole_officer_name`, `agency`, `address_1`, `address_2`, `city`, `state`, `zip_code`, `phone`, `pending_against`, `pa_if_other_specify`, `pa__above_explain`) VALUES
(1, 1, '0', NULL, '', '', '0', NULL, '', '', '', '', '', '', '', '', '', '', '', '', 'criminal charges, sentencing', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `std_life_event`
--

CREATE TABLE `std_life_event` (
  `life_event_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `movies` text NOT NULL,
  `losses` text NOT NULL,
  `sexual_abuse` text NOT NULL,
  `physical_abuse` text NOT NULL,
  `home_placement` text NOT NULL,
  `cultural_influence` text NOT NULL,
  `other_event` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_life_event`
--

INSERT INTO `std_life_event` (`life_event_id`, `student_id`, `movies`, `losses`, `sexual_abuse`, `physical_abuse`, `home_placement`, `cultural_influence`, `other_event`) VALUES
(1, 5, 'sss', 'ssssssss', 'ssssss', 'sssssssssssssssss', 'ssssssssss', 'sssssssss', 'sssssssss'),
(2, 5, 'Moves', 'Losses', 'Sexual Abuse/Rape', 'Physical Abuse/Neglect', 'Foster Home Placement or Institutionalization', 'Ethnic/Cultural Influences', 'Other'),
(3, 1, 'v', 'v', 'v', 'v', 'v', 'v', 'v');

-- --------------------------------------------------------

--
-- Table structure for table `std_marital_history`
--

CREATE TABLE `std_marital_history` (
  `marital_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `current_marital_status` text NOT NULL,
  `living_arrangement` text NOT NULL,
  `if_other_la` text DEFAULT NULL,
  `current_spouse_name` text DEFAULT NULL,
  `current_spouse_address_line1` text DEFAULT NULL,
  `current_spouse_address_line2` text DEFAULT NULL,
  `current_spouse_city` text DEFAULT NULL,
  `current_spouse_state` text DEFAULT NULL,
  `current_spouse_zip_code` text DEFAULT NULL,
  `current_spouse_home_phone` text DEFAULT NULL,
  `current_spouse_work_phone` text DEFAULT NULL,
  `relation_with_spouse` text DEFAULT NULL,
  `problem_with_spouse` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_marital_history`
--

INSERT INTO `std_marital_history` (`marital_history_id`, `student_id`, `current_marital_status`, `living_arrangement`, `if_other_la`, `current_spouse_name`, `current_spouse_address_line1`, `current_spouse_address_line2`, `current_spouse_city`, `current_spouse_state`, `current_spouse_zip_code`, `current_spouse_home_phone`, `current_spouse_work_phone`, `relation_with_spouse`, `problem_with_spouse`) VALUES
(1, 5, 'single', 'with parents', 'If Other, please specify', 'Current Spouse Full Name', 'Address Line1', 'Address Line2:', 'City', '*State', '*Zip', '*Home Phone', 'Work Phone:', 'Describe your relationship with your spouse', 'Describe any problems or concerns related to your relationship with your spouse or girlfriend'),
(2, 5, 'single', 'with parents', 'If Other, please specify', 'Current Spouse Full Name', 'Address Line1', 'Address Line2:', 'City', '*State', '*Zip', '*Home Phone', 'Work Phone:', 'Describe your relationship with your spouse', 'Describe any problems or concerns related to your relationship with your spouse or girlfriend'),
(3, 5, 'single', 'with parents', 'If Other, please specify', 'Current Spouse Full Name', 'Address Line1', 'Address Line2:', 'City', '*State', '*Zip', '*Home Phone', 'Work Phone:', 'Describe your relationship with your spouse', 'Describe any problems or concerns related to your relationship with your spouse or girlfriend'),
(4, 5, 'single', 'with parents', 'If Other, please specify', 'Current Spouse Full Name', 'Address Line1', 'Address Line2:', 'City', '*State', '*Zip', '*Home Phone', 'Work Phone:', 'Describe your relationship with your spouse', 'Describe any problems or concerns related to your relationship with your spouse or girlfriend'),
(5, 5, 'single', 'with parents', 'If Other, please specify', 'Current Spouse Full Name', 'Address Line1', 'Address Line2:', 'City', '*State', '*Zip', '*Home Phone', 'Work Phone:', 'Describe your relationship with your spouse', 'Describe any problems or concerns related to your relationship with your spouse or girlfriend'),
(6, 5, 'single', 'with parents', 'If Other, please specify', 'Current Spouse Full Name', 'Address Line1', 'Address Line2:', 'City', '*State', '*Zip', '*Home Phone', 'Work Phone:', 'Describe your relationship with your spouse', 'Describe any problems or concerns related to your relationship with your spouse or girlfriend'),
(7, 5, 'single', 'with parents', 'If Other, please specify', 'Current Spouse Full Name', 'Address Line1', 'Address Line2:', 'City', '*State', '*Zip', '*Home Phone', 'Work Phone:', 'Describe your relationship with your spouse', 'Describe any problems or concerns related to your relationship with your spouse or girlfriend'),
(8, 5, 'single', 'alone, with parents, with spouse, with others_nr, with others_r', '', '', '', '', '', '', '', '', '', '', ''),
(9, 5, 'single', 'alone, with parents', '', '', '', '', '', '', '', '', '', '', ''),
(10, 5, 'separated', 'alone, with parents', '', '', '', '', '', '', '', '', '', '', ''),
(11, 5, 'single', 'alone, with parents', '', '', '', '', '', '', '', '', '', '', ''),
(12, 5, 'single', 'alone, with parents', '', '', '', '', '', '', '', '', '', '', ''),
(13, 5, 'single', 'with parents, with spouse', '', '', '', '', '', '', '', '', '', '', ''),
(14, 5, 'single', 'alone, with parents', '', '', '', '', '', '', '', '', '', '', ''),
(15, 5, 'living together', 'alone, with parents', '', '', '', '', '', 'd', 'd', 'd', '', '', ''),
(16, 1, 'living together', 'alone, with spouse, with others_nr', 'z', 'z', 'z', 'z', 'z', 'z', 'z', 'z', 'z', 'z', 'z');

-- --------------------------------------------------------

--
-- Table structure for table `std_medical_history`
--

CREATE TABLE `std_medical_history` (
  `medical_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `drag_abuse` text DEFAULT NULL,
  `alcoholism` text DEFAULT NULL,
  `physical_problems` text DEFAULT NULL,
  `mental_problems` text DEFAULT NULL,
  `illness_experienced_as_child` text DEFAULT NULL,
  `have_diet_requirement` tinyint(4) DEFAULT NULL,
  `diet_requirement_reason` text DEFAULT NULL,
  `last_teeth_examined` text DEFAULT NULL,
  `have_teeth_problem_currently` tinyint(4) DEFAULT NULL,
  `teeth_problem_currently_reason` text DEFAULT NULL,
  `packs_of_cigarette` text DEFAULT NULL,
  `cups_of_coffee` text DEFAULT NULL,
  `cups_of_tea` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_medical_history`
--

INSERT INTO `std_medical_history` (`medical_history_id`, `student_id`, `drag_abuse`, `alcoholism`, `physical_problems`, `mental_problems`, `illness_experienced_as_child`, `have_diet_requirement`, `diet_requirement_reason`, `last_teeth_examined`, `have_teeth_problem_currently`, `teeth_problem_currently_reason`, `packs_of_cigarette`, `cups_of_coffee`, `cups_of_tea`) VALUES
(1, 5, 'grandparent', 'grandparent, father', 'grandparent', 'grandparent, father', 'z', 1, 'z', '', 1, 'z', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `std_military_history`
--

CREATE TABLE `std_military_history` (
  `military_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `is_served_us_army` text DEFAULT NULL,
  `branch_of_service` text DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `discharge_date` date DEFAULT NULL,
  `rank` text DEFAULT NULL,
  `discharge_recieved` text DEFAULT NULL,
  `eligible_for_mb` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_military_history`
--

INSERT INTO `std_military_history` (`military_history_id`, `student_id`, `is_served_us_army`, `branch_of_service`, `entry_date`, `discharge_date`, `rank`, `discharge_recieved`, `eligible_for_mb`) VALUES
(1, 5, '1', '0', '2019-10-03', '2019-09-18', 'Rank Attained', '1', '1'),
(2, 5, '1', 'If Yes, Branch of Service', '2019-11-03', '2019-09-18', 'Rank Attained', '1', '1'),
(3, 5, '0', '', '0000-00-00', '0000-00-00', '', NULL, NULL),
(4, 1, '1', 'z', '2019-09-03', '0000-00-00', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `std_most_recent_job`
--

CREATE TABLE `std_most_recent_job` (
  `most_recent_job_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `employer` text DEFAULT NULL,
  `employed_from` text DEFAULT NULL,
  `employed_until` text DEFAULT NULL,
  `position` text DEFAULT NULL,
  `leaving_reasonleaving_reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_most_recent_job`
--

INSERT INTO `std_most_recent_job` (`most_recent_job_id`, `student_id`, `employer`, `employed_from`, `employed_until`, `position`, `leaving_reasonleaving_reason`) VALUES
(1, 0, 'a', 'a', 'a', 'a', 'a'),
(2, 0, 'c', 'c', 'c', 'c', 'c'),
(3, 0, 'rr', 'r', 'r', 'r', 'r'),
(4, 0, 'c', 'c', 'c', 'c', 'c'),
(5, 0, 'rr', 'r', 'r', 'r', 'r'),
(6, 0, 'c', 'c', 'c', 'c', 'c'),
(7, 0, 'rr', 'r', 'r', 'r', 'r'),
(8, 0, 'c', 'c', 'c', 'c', 'c'),
(9, 0, 'rr', 'r', 'r', 'r', 'r');

-- --------------------------------------------------------

--
-- Table structure for table `std_occupational_history`
--

CREATE TABLE `std_occupational_history` (
  `occupational_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `profession` text DEFAULT NULL,
  `jobs_last_two_years` text DEFAULT NULL,
  `present_employement_status` text DEFAULT NULL,
  `most_recent_job_id` text DEFAULT NULL,
  `current_avg_monthly_income` int(11) DEFAULT NULL,
  `primary_income_source` int(11) DEFAULT NULL,
  `future_occupational_goal` text DEFAULT NULL,
  `skills` text DEFAULT NULL,
  `have_injury_in_teen_challenge` text DEFAULT NULL,
  `injury_reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_occupational_history`
--

INSERT INTO `std_occupational_history` (`occupational_history_id`, `student_id`, `profession`, `jobs_last_two_years`, `present_employement_status`, `most_recent_job_id`, `current_avg_monthly_income`, `primary_income_source`, `future_occupational_goal`, `skills`, `have_injury_in_teen_challenge`, `injury_reason`) VALUES
(1, 5, 'c', 'c', 'unemployed_not_sought', '8, 9', 0, 0, 's', 's', '0', 's'),
(2, 5, '', '', NULL, NULL, 0, 0, '', '', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `std_personality_info`
--

CREATE TABLE `std_personality_info` (
  `personality_info_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `is_expressive` tinyint(4) NOT NULL,
  `explanation_is_expressive` text NOT NULL,
  `is_rational` tinyint(4) NOT NULL,
  `explanation_is_rational` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_personality_info`
--

INSERT INTO `std_personality_info` (`personality_info_id`, `student_id`, `is_expressive`, `explanation_is_expressive`, `is_rational`, `explanation_is_rational`) VALUES
(1, 1, 1, 'bfgfbtrhbtyr', 1, 'bgfdbgfbfgbd'),
(2, 2, 1, 's', 1, 's'),
(3, 3, 1, 's', 1, 's'),
(4, 1, 1, 'p', 1, 'p');

-- --------------------------------------------------------

--
-- Table structure for table `std_physicial_info`
--

CREATE TABLE `std_physicial_info` (
  `physicial_info_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `physician_name` text DEFAULT NULL,
  `physician_address1` text DEFAULT NULL,
  `physician_address2` text DEFAULT NULL,
  `physician_city` text DEFAULT NULL,
  `physician_state` text DEFAULT NULL,
  `physician_zip` text DEFAULT NULL,
  `physician_phone` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `std_problem_definition`
--

CREATE TABLE `std_problem_definition` (
  `problem_definition_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `main_problem` text NOT NULL,
  `what_done_about_main_problem` text NOT NULL,
  `greatest_needs` text NOT NULL,
  `is_in_problem_before` text NOT NULL,
  `problem_type` tinyint(4) NOT NULL,
  `programs_been_in_before` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_problem_definition`
--

INSERT INTO `std_problem_definition` (`problem_definition_id`, `student_id`, `main_problem`, `what_done_about_main_problem`, `greatest_needs`, `is_in_problem_before`, `problem_type`, `programs_been_in_before`) VALUES
(1, 5, 'aa', 'bb', 'cc', '1', 0, 'dd'),
(2, 5, 'a', 'a', 'a', '1', 0, 'a');

-- --------------------------------------------------------

--
-- Table structure for table `std_reference`
--

CREATE TABLE `std_reference` (
  `reference_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `reference_name` text DEFAULT NULL,
  `reference_address_line1` text DEFAULT NULL,
  `reference_address_line2` text DEFAULT NULL,
  `reference_city` text DEFAULT NULL,
  `reference_state` text DEFAULT NULL,
  `reference_zip_code` text DEFAULT NULL,
  `reference_home_phone` text DEFAULT NULL,
  `reference_work_phone` text DEFAULT NULL,
  `reference_relation_to_student` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_reference`
--

INSERT INTO `std_reference` (`reference_id`, `student_id`, `reference_name`, `reference_address_line1`, `reference_address_line2`, `reference_city`, `reference_state`, `reference_zip_code`, `reference_home_phone`, `reference_work_phone`, `reference_relation_to_student`) VALUES
(1, 1, 'bfdbrtdbt', 'bfgdbgfb', 'fgbggfb', 'bfgfbrdtbg', 'bdgbgdbgf', 'bfbgfbgf', 'bfgbgfbgd', 'bfbgfb', 'bgdbg'),
(2, 2, '', '', '', '', '', '', '', '', ''),
(3, 3, '', '', '', '', '', '', '', '', ''),
(4, 1, 'p', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', 'aa', 'p');

-- --------------------------------------------------------

--
-- Table structure for table `std_social_involvement_history`
--

CREATE TABLE `std_social_involvement_history` (
  `social_involvement_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `religion` text DEFAULT NULL,
  `sports` text DEFAULT NULL,
  `peer_group` text NOT NULL,
  `community_affiliation` text NOT NULL,
  `hobbies` text DEFAULT NULL,
  `other` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_social_involvement_history`
--

INSERT INTO `std_social_involvement_history` (`social_involvement_history_id`, `student_id`, `religion`, `sports`, `peer_group`, `community_affiliation`, `hobbies`, `other`) VALUES
(1, 1, 'c', 'c', 'c', 'c', 'c', 'c');

-- --------------------------------------------------------

--
-- Table structure for table `std_social_security`
--

CREATE TABLE `std_social_security` (
  `social_security_id` int(11) NOT NULL,
  `student_id` int(255) NOT NULL,
  `social_security_number` text NOT NULL,
  `date_of_birth` date NOT NULL,
  `drivers_license_state` text DEFAULT NULL,
  `drivers_license_number` text DEFAULT NULL,
  `drivers_license_status` text DEFAULT NULL,
  `suspended_reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `std_social_security`
--

INSERT INTO `std_social_security` (`social_security_id`, `student_id`, `social_security_number`, `date_of_birth`, `drivers_license_state`, `drivers_license_number`, `drivers_license_status`, `suspended_reason`) VALUES
(1, 1, '313123123', '2019-09-02', '12321313', '423423432432', 'valid', 'fdbgfbgd'),
(2, 2, 'ss', '2019-09-17', '', '', NULL, ''),
(3, 3, 'ss', '2019-09-17', '', '', NULL, ''),
(4, 1, 'ss', '2019-09-02', 'aa', 'aa', 'valid', 'aa');

-- --------------------------------------------------------

--
-- Table structure for table `std_spiritual_history`
--

CREATE TABLE `std_spiritual_history` (
  `spiritual_history_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `have_born_again` text DEFAULT NULL,
  `born_date` text DEFAULT NULL,
  `born_place` text DEFAULT NULL,
  `current_spiritual_condition` text DEFAULT NULL,
  `circumstances` text DEFAULT NULL,
  `denomination_preference` text DEFAULT NULL,
  `attend_charch` text DEFAULT NULL,
  `is_member_of_charch` text DEFAULT NULL,
  `attend_charch_as_child` text DEFAULT NULL,
  `which_denomination` text DEFAULT NULL,
  `age_when_stop` text DEFAULT NULL,
  `stop_reason` text DEFAULT NULL,
  `do_believe_god` text DEFAULT NULL,
  `do_pray` text DEFAULT NULL,
  `read_bibel` text DEFAULT NULL,
  `read_other` text DEFAULT NULL,
  `other_book_name` text DEFAULT NULL,
  `recent_change_in_rl` text DEFAULT NULL,
  `involved_in_cults` text DEFAULT NULL,
  `other_cults` text DEFAULT NULL,
  `explanation` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `std_training_list`
--

CREATE TABLE `std_training_list` (
  `training_list_id` int(11) NOT NULL,
  `type_of_skill` text DEFAULT NULL,
  `date_of_training` text DEFAULT NULL,
  `have_cirtificate_issued` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_activity`
--

CREATE TABLE `student_activity` (
  `id` int(255) NOT NULL,
  `std_name` text NOT NULL,
  `std_activity` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_activity`
--

INSERT INTO `student_activity` (`id`, `std_name`, `std_activity`) VALUES
(1, 'john doe', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ');

-- --------------------------------------------------------

--
-- Table structure for table `student_chronological_entry`
--

CREATE TABLE `student_chronological_entry` (
  `id` int(255) NOT NULL,
  `label_check` text NOT NULL,
  `entry_des` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_chronological_entry`
--

INSERT INTO `student_chronological_entry` (`id`, `label_check`, `entry_des`) VALUES
(1, 'l, c, f, m', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `student_id` int(11) NOT NULL,
  `first_name` text NOT NULL,
  `middle_name` text DEFAULT NULL,
  `last_name` text NOT NULL,
  `address_line1` text NOT NULL,
  `address_line2` text DEFAULT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `zip_code` text NOT NULL,
  `home_phone` text NOT NULL,
  `work_phone` text DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`student_id`, `first_name`, `middle_name`, `last_name`, `address_line1`, `address_line2`, `city`, `state`, `zip_code`, `home_phone`, `work_phone`, `email`, `created_at`) VALUES
(1, 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', 'q', '2019-09-25 18:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `activation_selector` varchar(255) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `forgotten_password_selector` varchar(255) DEFAULT NULL,
  `forgotten_password_code` varchar(255) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_selector` varchar(255) DEFAULT NULL,
  `remember_code` varchar(255) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$12$zKsLvuKL49ful0YJLOV7tOQPrCcsheGWpJ8z.k3RjQ9rOzXZUCdaG', 'admin@admin.com', NULL, '', NULL, NULL, NULL, NULL, NULL, 1268889823, 1569654989, 1, 'Admin', 'istrator', 'ADMIN', '0');

-- --------------------------------------------------------

--
-- Table structure for table `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `std_appearance`
--
ALTER TABLE `std_appearance`
  ADD PRIMARY KEY (`appearance_id`);

--
-- Indexes for table `std_children`
--
ALTER TABLE `std_children`
  ADD PRIMARY KEY (`children_id`);

--
-- Indexes for table `std_children_info`
--
ALTER TABLE `std_children_info`
  ADD PRIMARY KEY (`children_info_id`);

--
-- Indexes for table `std_crime_history`
--
ALTER TABLE `std_crime_history`
  ADD PRIMARY KEY (`crime_history_id`);

--
-- Indexes for table `std_drug_history`
--
ALTER TABLE `std_drug_history`
  ADD PRIMARY KEY (`drug_history_id`);

--
-- Indexes for table `std_emergency_contact`
--
ALTER TABLE `std_emergency_contact`
  ADD PRIMARY KEY (`emergency_contact_id`);

--
-- Indexes for table `std_ethnic_background`
--
ALTER TABLE `std_ethnic_background`
  ADD PRIMARY KEY (`ethnic_background_id`);

--
-- Indexes for table `std_family_history`
--
ALTER TABLE `std_family_history`
  ADD PRIMARY KEY (`family_history_id`);

--
-- Indexes for table `std_family_member`
--
ALTER TABLE `std_family_member`
  ADD PRIMARY KEY (`family_member_id`);

--
-- Indexes for table `std_financial_status`
--
ALTER TABLE `std_financial_status`
  ADD PRIMARY KEY (`financial_status`);

--
-- Indexes for table `std_in_prison`
--
ALTER TABLE `std_in_prison`
  ADD PRIMARY KEY (`in_prison_id`);

--
-- Indexes for table `std_legal_history`
--
ALTER TABLE `std_legal_history`
  ADD PRIMARY KEY (`legal_history_id`);

--
-- Indexes for table `std_life_event`
--
ALTER TABLE `std_life_event`
  ADD PRIMARY KEY (`life_event_id`);

--
-- Indexes for table `std_marital_history`
--
ALTER TABLE `std_marital_history`
  ADD PRIMARY KEY (`marital_history_id`);

--
-- Indexes for table `std_medical_history`
--
ALTER TABLE `std_medical_history`
  ADD PRIMARY KEY (`medical_history_id`);

--
-- Indexes for table `std_military_history`
--
ALTER TABLE `std_military_history`
  ADD PRIMARY KEY (`military_history_id`);

--
-- Indexes for table `std_most_recent_job`
--
ALTER TABLE `std_most_recent_job`
  ADD PRIMARY KEY (`most_recent_job_id`);

--
-- Indexes for table `std_occupational_history`
--
ALTER TABLE `std_occupational_history`
  ADD PRIMARY KEY (`occupational_history_id`);

--
-- Indexes for table `std_personality_info`
--
ALTER TABLE `std_personality_info`
  ADD PRIMARY KEY (`personality_info_id`);

--
-- Indexes for table `std_physicial_info`
--
ALTER TABLE `std_physicial_info`
  ADD PRIMARY KEY (`physicial_info_id`);

--
-- Indexes for table `std_problem_definition`
--
ALTER TABLE `std_problem_definition`
  ADD PRIMARY KEY (`problem_definition_id`);

--
-- Indexes for table `std_reference`
--
ALTER TABLE `std_reference`
  ADD PRIMARY KEY (`reference_id`);

--
-- Indexes for table `std_social_involvement_history`
--
ALTER TABLE `std_social_involvement_history`
  ADD PRIMARY KEY (`social_involvement_history_id`);

--
-- Indexes for table `std_social_security`
--
ALTER TABLE `std_social_security`
  ADD PRIMARY KEY (`social_security_id`);

--
-- Indexes for table `std_spiritual_history`
--
ALTER TABLE `std_spiritual_history`
  ADD PRIMARY KEY (`spiritual_history_id`);

--
-- Indexes for table `std_training_list`
--
ALTER TABLE `std_training_list`
  ADD PRIMARY KEY (`training_list_id`);

--
-- Indexes for table `student_activity`
--
ALTER TABLE `student_activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_chronological_entry`
--
ALTER TABLE `student_chronological_entry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_email` (`email`),
  ADD UNIQUE KEY `uc_activation_selector` (`activation_selector`),
  ADD UNIQUE KEY `uc_forgotten_password_selector` (`forgotten_password_selector`),
  ADD UNIQUE KEY `uc_remember_selector` (`remember_selector`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `std_appearance`
--
ALTER TABLE `std_appearance`
  MODIFY `appearance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `std_children`
--
ALTER TABLE `std_children`
  MODIFY `children_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `std_children_info`
--
ALTER TABLE `std_children_info`
  MODIFY `children_info_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `std_crime_history`
--
ALTER TABLE `std_crime_history`
  MODIFY `crime_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `std_drug_history`
--
ALTER TABLE `std_drug_history`
  MODIFY `drug_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `std_emergency_contact`
--
ALTER TABLE `std_emergency_contact`
  MODIFY `emergency_contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `std_ethnic_background`
--
ALTER TABLE `std_ethnic_background`
  MODIFY `ethnic_background_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `std_family_history`
--
ALTER TABLE `std_family_history`
  MODIFY `family_history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `std_family_member`
--
ALTER TABLE `std_family_member`
  MODIFY `family_member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `std_financial_status`
--
ALTER TABLE `std_financial_status`
  MODIFY `financial_status` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `std_in_prison`
--
ALTER TABLE `std_in_prison`
  MODIFY `in_prison_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `std_legal_history`
--
ALTER TABLE `std_legal_history`
  MODIFY `legal_history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `std_life_event`
--
ALTER TABLE `std_life_event`
  MODIFY `life_event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `std_marital_history`
--
ALTER TABLE `std_marital_history`
  MODIFY `marital_history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `std_medical_history`
--
ALTER TABLE `std_medical_history`
  MODIFY `medical_history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `std_military_history`
--
ALTER TABLE `std_military_history`
  MODIFY `military_history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `std_most_recent_job`
--
ALTER TABLE `std_most_recent_job`
  MODIFY `most_recent_job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `std_occupational_history`
--
ALTER TABLE `std_occupational_history`
  MODIFY `occupational_history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `std_personality_info`
--
ALTER TABLE `std_personality_info`
  MODIFY `personality_info_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `std_physicial_info`
--
ALTER TABLE `std_physicial_info`
  MODIFY `physicial_info_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `std_problem_definition`
--
ALTER TABLE `std_problem_definition`
  MODIFY `problem_definition_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `std_reference`
--
ALTER TABLE `std_reference`
  MODIFY `reference_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `std_social_involvement_history`
--
ALTER TABLE `std_social_involvement_history`
  MODIFY `social_involvement_history_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `std_social_security`
--
ALTER TABLE `std_social_security`
  MODIFY `social_security_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `std_spiritual_history`
--
ALTER TABLE `std_spiritual_history`
  MODIFY `spiritual_history_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `std_training_list`
--
ALTER TABLE `std_training_list`
  MODIFY `training_list_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_activity`
--
ALTER TABLE `student_activity`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_chronological_entry`
--
ALTER TABLE `student_chronological_entry`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_info`
--
ALTER TABLE `student_info`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
