<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Auth/login';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;


$route['records'] = 'RecordController/Record';
$route['dashboard'] = 'RecordController/Dashboard';
$route['academic'] = 'RecordController/Academic';
$route['student-test-score'] = 'RecordController/StudentTestScore';
$route['logout'] = 'Auth/logout';
$route['login'] = 'Auth/login';

//students
$route['student_manager'] = 'RecordController/studentManager';
$route['student_detail/(:any)'] = 'RecordController/studentDeatil/$1';


//$route['save_student_entry_value'] = 'RecordController/SaveStudentEntry';
$route['save_student_activity_value'] = 'RecordController/SaveStudentActivity';
//Manually add student
$route['student_manager/manual_std/store'] = 'RegistrationController/manually_save_student';


//students Registration
$route['student_registration'] = 'RegistrationController/studentRegistration';
$route['register_form_1'] = 'RegistrationController/register_form_1';
$route['register_form_2'] = 'RegistrationController/register_form_2';
$route['register_form_3'] = 'RegistrationController/register_form_3';
$route['register_form_4'] = 'RegistrationController/register_form_4';
$route['register_form_5'] = 'RegistrationController/register_form_5';
$route['register_form_6'] = 'RegistrationController/register_form_6';
$route['register_form_7'] = 'RegistrationController/register_form_7';
$route['register_form_8'] = 'RegistrationController/register_form_8';

$route['save_registration_form1'] = 'RegistrationController/save_registration_form1';
$route['save_registration_form2'] = 'RegistrationController/save_registration_form2';
$route['save_registration_form3'] = 'RegistrationController/save_registration_form3';
$route['save_registration_form4'] = 'RegistrationController/save_registration_form4';
$route['save_registration_form5'] = 'RegistrationController/save_registration_form5';
$route['save_registration_form6'] = 'RegistrationController/save_registration_form6';
$route['save_registration_form7'] = 'RegistrationController/save_registration_form7';
$route['save_registration_form8'] = 'RegistrationController/save_registration_form8';

//incomming students detail
$route['incoming_student_detail/(:any)']='RecordController/incoming_student_detail/$1';
$route['page_1/(:any)'] = 'RecordController/page_1/$1';
$route['page_2/(:any)'] = 'RecordController/page_2/$1';
$route['page_3/(:any)'] = 'RecordController/page_3/$1';
$route['page_4/(:any)'] = 'RecordController/page_4/$1';
$route['page_5/(:any)'] = 'RecordController/page_5/$1';
$route['page_6/(:any)'] = 'RecordController/page_6/$1';
$route['page_7/(:any)'] = 'RecordController/page_7/$1';
$route['page_8/(:any)'] = 'RecordController/page_8/$1';

//activate student
$route['activate_student/(:any)'] = 'RecordController/activate_student/$1';

//activity routue
$route['activity'] = 'ActivityController/ActivityLog';
$route['activity/(:any)'] = 'ActivityController/activity/$1';
$route['save_activity_value'] = 'ActivityController/SaveActivityValue';
$route['ajax/activity/get_data'] = 'ActivityController/get_data';
$route['ajax/get_data/date_filter'] = 'ActivityController/date_filter';
///chronologicals routes
$route['chronolical/get_data'] = 'ChronologicalsController/get_data';
$route['chronolical/save'] = 'ChronologicalsController/save';
$route['chronologicals'] = 'ChronologicalsController/Chronologicals';
$route['chronologicals/(:any)'] = 'ChronologicalsController/chronologicals/$1';

//descipline routes
$route['students-discipline'] = 'DisciplineController/StudentDiscipline';
$route['students-discipline/(:any)'] = 'DisciplineController/StudentDiscipline/$1';
$route['students/discipline/store'] = 'DisciplineController/store';
$route['students/discipline/details/(:any)'] = 'DisciplineController/disciplineDetails/$1';



$route['save_test_score_value'] = 'RecordController/SaveStudentTestScore';
$route['students_gsnc_psnc/(:any)'] = 'RecordController/StudentGSNCPSNC/$1';

//delete rouete
$route['delete_student'] = 'RecordController/delete_student';

//developemnt plan route
$route['development_plan'] = 'DevPlanController/development_plan';


//AA routes
$route['new-contract/(:any)'] = 'ContractController/StudentNewContract/$1';
$route['update_due_date'] = 'ContractController/UpdateContractDueDate';
$route['update_unit_title'] = 'ContractController/UpdateContractUnitTitle';
$route['update_major_theme'] = 'ContractController/UpdateContractMajorTheme';
$route['update_minor_theme'] = 'ContractController/UpdateContractMinorTheme';
$route['update_goals'] = 'ContractController/UpdateContractGoals';
$route['update_lessons'] = 'ContractController/UpdateContractLessons';
$route['update_scripture'] = 'ContractController/UpdateContractScripture';
$route['update_scripture_projects'] = 'ContractController/UpdateContractScriptureProject';
$route['update_character'] = 'ContractController/UpdateContractCharacter';
$route['update_character_project'] = 'ContractController/UpdateContractCharacterProject';
$route['update_personal_reading'] = 'ContractController/UpdateContractPersonalReading';
$route['update_bible_reading'] = 'ContractController/UpdateContractBibleReading';
$route['update_special_projects'] = 'ContractController/UpdateContractSpecialProject';
$route['update_scripture_worksheet'] = 'ContractController/update_scripture_worksheet';
$route['update_scripture_finaltest'] = 'ContractController/update_scripture_finaltest';
$route['update_assign_value/(:any)'] = 'ContractController/update_assign_value/$1';
$route['update_complete_value/(:any)'] = 'ContractController/update_complete_value/$1';
$route['update_reassign_value/(:any)'] = 'ContractController/update_reassign_value/$1';
$route['update_unassign_value/(:any)'] = 'ContractController/update_unassign_value/$1';
$route['delete-contract/(:any)'] = 'ContractController/DeleteContract/$1';
$route['student-contract/(:any)/(:any)'] = 'ContractController/StudentContract/$1/$2';

