<div class="container">
    <div class="register-form-list">
        <ul id="nav" class="nav nav-tabs" style="">
            <li><a class="nav-item nav-link active" href="<?php echo base_url()?>register_form_1" id="p1">Page 1</a></li>
            <li><a class="nav-item nav-link" href="<?php echo base_url()?>register_form_2"  id="p2" >Page 2</a></li>
            <li><a class="nav-item nav-link" href="<?php echo base_url()?>register_form_3"  id="p3">Page 3</a></li>
            <li><a class="nav-item nav-link" href="<?php echo base_url()?>register_form_4"  id="p4">Page 4</a></li>
            <li><a class="nav-item nav-link" href="<?php echo base_url()?>register_form_5"  id="p5">Page 5</a></li>
            <li><a class="nav-item nav-link" href="<?php echo base_url()?>register_form_6"  id="p6">Page 6</a></li>
            <li><a class="nav-item nav-link" href="<?php echo base_url()?>register_form_7"  id="p7">Page 7</a></li>
            <li><a class="nav-item nav-link" href="<?php echo base_url()?>register_form_8"  id="p8">Page 8</a></li>
        </ul>

        <div id="ajax-content"></div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $("#nav li a").click(function() {

            // $("#nav li a").removeClass('current');
            // $(this).addClass('current');

            $("#nav li a").removeClass('active');
            $(this).addClass('active');

            $.ajax({ url: this.href, success: function(html) {
                    $("#ajax-content").empty().append(html);
                }
            });
            return false;
        });

        $.ajax({ url: 'register_form_1', success: function(html) {
                $("#ajax-content").empty().append(html);
            }
        });
    });

    //$(document).ready(function() {
    //    $("#nav li a").click(function() {
    //
    //        $("#ajax-content").empty().append("<div id='loading'><img src='<?php //echo base_url()?>//assets/images/loader.gif' alt='Loading' /></div>");
    //        $("#nav li a").removeClass('current');
    //        $(this).addClass('current');
    //
    //        $.ajax({ url: this.href, success: function(html) {
    //                $("#ajax-content").empty().append(html);
    //            }
    //        });
    //        return false;
    //    });
    //});

</script>