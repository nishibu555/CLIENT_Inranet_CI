
<div class="container">
    <div class="row">
        <div class="col">
            <div class="sub_nav">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active"><a href="<?php echo base_url()?>dashboard">Home</a></li>
                        <li class="breadcrumb-item active" ><a href="<?php echo base_url()?>records">Records</a></li>
                        <li class="breadcrumb-item active" ><a href="<?php echo base_url()?>student_manager">Students Manager</a></li>
                        <li class="breadcrumb-item active" ><a href="<?php echo base_url()?>academic">Academics</a></li>
                        <li class="breadcrumb-item active" ><a href="<?php echo base_url()?>students_gsnc_psnc/<?php echo @$student_id?>"><?php echo @$student_name?></a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="side_div1">
                <h5>RECORDS</h5>
                <img style="width: 100%;" src="<?php echo base_url()?>assets/images/icon_records.png">
            </div>

        </div>

        <div class="col-md-9">
            <div class="student_activity_log">
                <div class="table_title" style="margin-top: 30px;">
                    <h5>Student Manager:</h5>
                </div>
                <div class="student_academic">
                    <p style="margin-top: 6px;">Academics / <?php echo @$student_name?></p>
                    <div class="content_complete">
                        <p>GSNC – <span>2 Books Complete	(92.5% Pass Avg)</span></p>
                        <p>PSNC – <span>1 Contract Complete</span></p>
                    </div>
                </div>
            </div>
            <div class="gsnc-test-score">
                <h3>GSNC Test Score</h3>
                <table class="table table-responsive">
                    <thead>
                    <tr>
                        <th>Course Name</th>
                        <th>Test Date</th>
                        <th>Facilitator</th>
                        <th>Score</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php foreach(@$gsnc_values as $gsnc_value){?>
                    <tr>
                        <td><?php echo @$gsnc_value['title']?></td>
                        <td><?php echo @$gsnc_value['date']?></td>
                        <td><?php echo @$gsnc_value['author']?></td>
                        <td><?php echo @$gsnc_value['score']?></td>
                    </tr>
                    <?php }?>
                    </tbody>
                </table>
            </div>
            <div class="gsnc-test-score">
                <h3>PSNC Test Score</h3>
                <table class="table table-responsive">
                    <thead>
                    <tr>
                        <th></th>
                        <th>Assigned</th>
                        <th>Due</th>
                        <th>Complete</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i =1?>
                    <?php foreach($contracts_info as $contract_info){?>
                    <tr>
                        <td><a href="<?php echo base_url()?>student-contract/<?php echo @$student_id?>/<?php echo $contract_info['id']?>">Contract <?php echo $i;?></a></td>
                        <td><?php echo $contract_info['date_assigned']?></td>
                        <td><?php echo $contract_info['date_due']?></td>
                        <td><?php echo $contract_info['date_completed']?></td>
                    </tr>
                    <?php $i++?>
                    <?php }?>
                    </tbody>
                </table>
            </div>
            <div class="new-contract">
                <a href="<?php echo base_url()?>new-contract/<?php echo @$student_id?>" class="btn btn-primary contract-btn">New Contract</a>
            </div>
        </div><!--end col-md-9-->
    </div>
