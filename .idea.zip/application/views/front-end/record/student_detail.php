
 <div class="container">
 	<div class="row">
 		<div class="col">
 			<div class="sub_nav">
 				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item active"><a href="<?= base_url()?>">Home</a></li>
				    <li class="breadcrumb-item active" ><a href="<?= base_url('records')?>">Records</a></li>
				    <li class="breadcrumb-item active" ><a href="<?= base_url('student_manager')?>">Student manager</a></li>
				    <li class="breadcrumb-item active" ><a href="#">Active Student</a></li>
				    <li class="breadcrumb-item active" ><a href="#"><?= $student_info->first_name.' '.$student_info->last_name?></a></li>
				  </ol>
				</nav>
 			</div>
 		</div>
 	</div>
 	<div class="row">
	 	<div class="col-md-4">
	 		<div class="side_div1">
	 			<p>RECORDS</p>
                <img style="width: 100%;" src="<?php echo base_url('assets/images/icon_records.png')?>">
	 		</div>

	 	</div>

	 	<div class="col-md-8">
	 		<div class="student_detail_title">
	 			<p>STUDENT MANAGER</p>
	 		</div>
	 		<div class="student_detail_title2">
	 			<p><?= $student_info->first_name.' '.$student_info->last_name?>:  <?= $student_info->status==1 ? 'Active' :($student_info->status==2 ? 'Graduate' : 'Discharge')?> - need to change</p>
	 		</div>


	 		<div>
	 			<div class="student_detail_subtitle1">
	 				<p>Students Vitals</p>
	 			</div>
	 			<div class="row">
	 				<div class="col-md-4">
	 					<img src="<?= base_url('assets/images/default_profile.jpg')?>" style="width: 200px;box-shadow: 0px 0px 0px 3px #2b78c24f, 0px 0px 0px 6px #cdd0d3;border-radius: 5px;">
	 				</div>
	 				<div class="col-md-4 profile_info">
	 					<small>First name: <span><?= $student_info->first_name?></span></small><br>
	 					<small>last name: <span><?= $student_info->last_name?></span></small><br>
	 					<small>Date of entry: <span><?= date('d-m-Y', strtotime($student_info->created_at))?></span></small><br>
                        <?php  $complition_date = date('Y', strtotime($student_info->created_at))+1 ?>
	 					<small>Completion date: <span><?= date('d-m', strtotime($student_info->created_at)).'-'.$complition_date?></span></small><br>
                        
	 					<small>Date of birth: <span><?= date('d-m-Y', strtotime($std_social_security->date_of_birth))?></span></small><br>
	 					<small>SSN: <span><?= isset($student_info->ssn)?$student_info->ssn:''?></span></small><br>
	 					<small>Recidence: <span><?= $student_info->address_line1?></span></small><br>
	 					<small>Application: <span><?= $student_info->last_name?></span></small>
	 				</div>
	 				<div class="col-md-4 profile_info">
	 					<small>Counselor:  <span><?= isset($student_info->counselor)?$student_info->counselor: ''?></span><span></span></small><br>
	 					<small>Current phase: <span><?= isset($student_info->current_phase)?$student_info->current_phase:''?></span></small><br>
	 					<small>GSNC: <span><?= isset($student_info->gsnc)?$student_info->gsnc:''?></span></small><br>
	 					<small>PSNC: <span><?= isset($student_info->psnc)?$student_info->psnc:''?></span></small><br>
	 					<small>Married: <span><?= isset($std_marital_history->current_marital_status)?$std_marital_history->current_marital_status:''?></span></small><br>
	 					<small>Court-ordered: <span><?=isset($std_crime_history->crime_history_id)? 'Yes' : 'No'?></span></small><br>
	 					<small>Education: <span><?= isset($std_academic_info->highest_grade)?$std_academic_info->highest_grade:''?></span></small><br>
	 				</div>
	 			</div>
	 		</div>
            <br>
	 		<div>
	 			<div class="student_detail_subtitle">
	 				<p>Students Activity
	 					<span style="margin-left: 20px; font-size: 11px; color: #2b78c2">
                            <a href="<?= base_url('activity/'.$student_info->student_id)?>" class="text-primary" ><i class="fa fa-plus"></i> Add Entry</a>
	 				    </span>
	 				</p>
	 			</div>
	 			<div class="student_detail_description">
                    <?php foreach($student_activity as $activity):?>
                    <p><span><?= date('D',strtotime($activity->activity_date))?></span>  <span><?= date('d/m/Y',strtotime($activity->activity_date))?> </span>at <span><?= date('h:i:s A',strtotime($activity->activity_date))?></span> by <span><?= $activity->author?></span></p>
                            <p>
	 				<p><?= $activity->activity?></p>
                    <?php endforeach;?>
	 			</div>
	 		</div>
            <br>
	 		<div>
	 			<div class="student_detail_subtitle">
	 				<p>Students Chronological
	 					<span style="margin-left: 20px; font-size: 11px; color: #2b78c2">
	 					  <a href="<?= base_url('chronologicals/'.$student_info->student_id)?>">Add Entry</a>
	 				    </span>
	 				</p>
	 			</div>
	 			<div class="student_detail_description">
                  <?php foreach($student_chronological as $data):?>
                    <div style="border-bottom: 1px solid #d6d6d6;padding:5px">
                        <p> <span><?= date('d/m/Y',strtotime($data->created_at))?> </span> <span>Code <?= $data->label_check?></span> by <span><?= $data->author ?></span></p>
	 				  <p><?= $data->entry_des?></p>
                    </div>
                <?php endforeach;?>
	 			</div>
	 		</div>
	 		<br>
	 		<div>
	 			<div class="student_detail_subtitle">
	 				<p>Students Decipline
	 					<span style="margin-left: 20px; font-size: 11px; color: #2b78c2">
	 					  <a href="<?= base_url('students-discipline/'.$student_info->student_id)?>">Add Entry</a>
	 				    </span>
	 				</p>
	 			</div>
	 			<div class="student_detail_description">
	 				<?php foreach($student_discipline as $data):?>
                    <div style="border-bottom: 1px solid #d6d6d6;padding:5px">
                        <p> <span><?= date('d/m/Y',strtotime($data->created_at))?> </span> <?= $data->status == '0' ? '<span style="color:red">Pending</span>': '<span style="color:green">Resolved</span>'?></p>
	 				  <p><?= $data->discipline_des?></p>
                    </div>
                <?php endforeach;?>
	 			</div>
	 		</div>
	 		<br>
	 		<div style="float: right;">
	 			<div style="width: 250px">
	 			  <button type="submit" class="btn btn-primary submit_button">Discharge Student</button>
	 		    </div>		
	 		</div>
	 	</div><!--col-9-->
 	</div><!--row-->
 </div>
<!-- activity Modal start-->
<div class="modal fade" id="add_activity_modal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title"><span id="hlabel">Add New</span> Activity</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                <div class="statusMsg"></div>
                <form role="form">
                    <div class="form-group">
                        <label>Activity</label>
                        <textarea name="activity" ></textarea>
                    </div>
                    <div class="form-group">
                        <label>Tags</label>
                        <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Enter last name" >
                    </div>
                    <input type="hidden" class="form-control" name="id" id="id"/>
                </form>
            </div>
            
            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-success" id="userSubmit">SUBMIT</button>
            </div>
        </div>
    </div>
</div>

