
<div class="container">
    <div class="row">
        <div class="col">
            <div class="sub_nav">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active"><a href="<?= base_url('/dashboard')?>">Home</a></li>
                        <li class="breadcrumb-item active" ><a href="<?= base_url('/records')?>">Records</a></li>
                        <li class="breadcrumb-item active" ><a href="<?= base_url('/student_manager')?>">Students Manager</a></li>
                        <li class="breadcrumb-item active" ><a href="">Student Discipline</a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3">
            <div class="side_div1">
                <p>RECORDS</p>
                <img style="width: 100%;" src="<?php echo base_url()?>assets/images/icon_records.png">
            </div>

        </div>

        <div class="col-md-9">
            <form  id="add_discipline_form">
                <div class="row">
                    <div class="col-md-9">
                        <div class="student_activity_log">
                            <div class="table_title" style="margin-top: 30px;">
                                <h5>Development Plans:</h5>
                            </div>
                            <div class="development_plan table-responsive">
                                <table class="table dev_plan_table">
                                   <thead>
                                     <tr>
                                        <th></th>
                                       <th colspan="2">
                                           <select style="padding: 3px 30px" class="form-control">
                                               <option>January 2019</option>
                                               <option>January 2019</option>
                                               <option>January 2019</option>
                                           </select>
                                       </th>
                                     </tr>
                                   </thead>
                                   <tbody>
                                        <tr>
                                            <td><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQRZlMVt6AobKzfB-EdNG7Z_gAumDDqayoIqZOhh_FyZ3n-tZLF" height="50px; width: 70px"></td>
                                            <td>Carter, Kevin</td>
                                            <td>Not Started</td>
                                            <td>Pastor Tim</td>
                                        </tr>
                                        <tr>
                                            <td><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQRZlMVt6AobKzfB-EdNG7Z_gAumDDqayoIqZOhh_FyZ3n-tZLF" height="50px; width: 70px"></td>
                                            <td>Carter, Kevin</td>
                                            <td>Not Started</td>
                                            <td>Pastor Tim</td>
                                        </tr>
                                   </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div><!--end col-md-9-->
    </div>


  