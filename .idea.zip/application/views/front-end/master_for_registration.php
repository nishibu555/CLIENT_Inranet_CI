<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>TCI-Intranet-Student-Proof</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets//css/jquery.datetimepicker.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/main.css">
</head>
<body>
    <header>
        <div class="init_menu">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <a class="navbar-brand" href="#"><img src="<?php echo base_url()?>assets/images/initranet-logo.png"></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse mr-l-100" id="navbarSupportedContent">
                        <h4>New Student Registration</h4>
                    </div>
                </nav>
            </div>
        </div>

    </header>
    
    <?php echo $content ?>

    <footer>
        <p>&copy; Teen challenge GA international, Inc. All rights reserved.<a href="#">Report Login issues.</a></p>
    </footer>
    <script src="<?php echo base_url()?>assets/js/jquery-3.4.1.js"></script>
    <script src="<?php echo base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>assets/js/custom.js"></script>


</body>
</html>
