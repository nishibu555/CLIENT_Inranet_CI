<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class StudentModel extends CI_Model
{

    public function GetAllData($tableName)
    {
        $this->db->select('*');
        $this->db->from($tableName);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;

    }
    public function InsertData($TableName,$data)
    {
        $this->db->insert($TableName, $data);
        return $this->db->insert_id();
    }
    public function getOneRow($TableName,$condition)
    {
        return $this->db->where($condition)->get($TableName)->row();
    }

    public function gsnc_value($std_id){

        $this->db->select('academics_scores.*,academics_gsnc.title');
        $this->db->from('academics_scores');
        $this->db->join('academics_gsnc','academics_scores.gsnc_id = academics_gsnc.id');
        $this->db->where('student_id',$std_id);
        $fetched_records = $this->db->get();
        return $users = $fetched_records->result_array();
//        return $this->db->row();
    }
}