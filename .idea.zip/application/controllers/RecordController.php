<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class RecordController extends CI_Controller {
   
    public function __construct()
    {
	    parent::__construct();
	    $this->load->library('form_validation');
        $this->load->model(['RegistrationModel','StudentModel','ContractModel']);
        $this->load->library('ion_auth');
        $this->load->helper('language');
        $this->lang->load('auth');

        if (!$this->ion_auth->logged_in())
        {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
    }

    public function logIn()
    {
//        $data = array();
//        $data['content']=$this->load->view('front-end/login',$data,true);
        $this->load->view('front-end/login');
    }
	public function Record()
    {
        $data = array();
        $data['content']=$this->load->view('front-end/record/records',$data,true);
        $this->load->view('front-end/master', $data);
    }

    public function Dashboard()
    {
        $data = array();
        $data['content']=$this->load->view('front-end/dashboard',$data,true);
        $this->load->view('front-end/master', $data);
    }
 public function StudentTestScore()
    {
        $data = array();
        $data['courses']=$this->StudentModel->GetAllData('academics_gsnc');
        $data['students']=$this->StudentModel->GetAllData('student_info');
        $data['content']=$this->load->view('front-end/record/new-test-score',$data,true);
        $this->load->view('front-end/master', $data);
    }


    public function Academic()
    {
        $data = array();
        $data['students'] = $this->StudentModel->GetAllData('student_info');
        $data['content']=$this->load->view('front-end/record/academic',$data,true);
        $this->load->view('front-end/master', $data);
    }


    public function studentManager(){
       $data = array();
        $condition=['acceptance_flag'=> 0];
        $data['incoming_student']=$this->RegistrationModel->get_result('student_info', $condition);
        $data['active_students']=$this->db->query('SELECT * FROM `student_info` WHERE `acceptance_flag` = 1 AND `status`=1 ORDER BY `student_id` DESC')->result();   $data['archive_student']=$this->db->query('SELECT * FROM `student_info` WHERE `status` != 1 ORDER BY `student_id` DESC')->result();
        //all student whos acceptance flag is 1 will be showed
        $data['content']=$this->load->view('front-end/record/student_manager', $data, true);
        $this->load->view('front-end/master', $data);
    }
	
     public function delete_student(){
          $this->db->where('student_id', $_POST['id']);
            $this->db->delete('student_info');
        $response['msg']="Student Successfully Deleted";
        echo json_encode($response);
     }
    
    public function studentDeatil($id){  
        
       
        $data['student_info'] = $this->db->query('SELECT * FROM `student_info` WHERE `student_id`='.$id)->row();
        $data['std_social_security'] = $this->db->query('SELECT * FROM `std_social_security` WHERE `student_id`='.$id)->row();

        
        $data['std_academic_info'] = $this->db->query('SELECT * FROM `std_academic_info` WHERE `student_id`='.$id)->row();
        
        $data['std_crime_history'] = $this->db->query('SELECT * FROM `std_crime_history` WHERE `student_id`='.$id)->row();
        
        $data['std_marital_history'] = $this->db->query('SELECT * FROM `std_marital_history` WHERE `student_id`='.$id)->row();
        
        $data['std_crime_history'] = $this->db->query('SELECT * FROM `std_crime_history` WHERE `student_id`='.$id)->row();
        
        $data['std_academic_info'] = $this->db->query('SELECT * FROM `std_academic_info` WHERE `student_id`='.$id)->row();
       


        
        $data['student_activity'] = $this->db->query('SELECT * FROM `activity_log` WHERE `student_id`='.$id.' ORDER BY `id` DESC')->result();
        $data['student_chronological'] = $this->db->query('SELECT * FROM `student_chronological_entry` WHERE `student_id`='.$id.' ORDER BY `id` DESC')->result();
        $data['student_discipline'] = $this->db->query('SELECT * FROM `std_discipline` WHERE `student_id`='.$id.' ORDER BY `id` DESC')->result();
//        echo $this->db->last_query();die;
//        var_dump($data['student_info']);
        $data['content']=$this->load->view('front-end/record/student_detail', $data, true);
        $this->load->view('front-end/master', $data);  
    }

    public function studentRegistration(){
        
        $this->load->view('front-end/record/student_registration');
    }


    public function StudentGSNCPSNC($std_id)
    {
        $condition = ['student_id'=> $std_id];
        $data=array();
        $student_name =$this->StudentModel->getOneRow('student_info',$condition);
        $data['student_id'] = $student_name->student_id;
        $data['student_name'] = $student_name->first_name.' '.$student_name->last_name;
        $data['gsnc_values']=$this->StudentModel->gsnc_value($std_id);
        $data['contracts_info']=$this->ContractModel->getMultipleRow('academics_contracts',$std_id);
        $data['content']=$this->load->view('front-end/record/student-gsnc-psnc',$data, true);
        $this->load->view('front-end/master', $data);
    }
    public function SaveStudentTestScore()
    {
        $id = $this->ion_auth->logged_in();
        $condition  = ['id'=> $id];
        $user_name  = $this->StudentModel->getOneRow('users',$condition);
        $author = $user_name->first_name;
        $course_id = $this->input->post('course_name',true);

        $response = array(
            'success'=> false,
            'error'=> false,
            'msg'=>''
        );
        $test = $this->input->post('test_score',true);
        $n =count($test);
        for ($i = 0;$i<$n;$i++)
        {
            $std_score=array();
            $std_score['gsnc_id']          = $course_id;
            $std_score['date']             = $this->input->post('test_date',true)[$i];
            $std_score['score']            = $this->input->post('test_score',true)[$i];
            $std_score['student_id']       = $this->input->post('std_id',true)[$i];
            $std_score['author']           = $author;

            $this->StudentModel->InsertData('academics_scores',$std_score);
        }

        $response['error']=false;
        $response['success']=true;
        $response['msg']="Student Score Successfully added";

        echo json_encode($response);

    }

    public function SaveStudentActivity()
    {

        $this->form_validation->set_rules('std_activity', 'Student Activity', 'required');

        if (empty($_POST['std_name']) || $_POST['std_name'] == "Student Name")
        {
            $this->form_validation->set_rules('std_name', 'Student Name', 'required');
        }

        $response = array(
            'success'=> false,
            'error'=> false,
            'msg'=>''
        );

        if ($this->form_validation->run() === true) {

            $std_activity=array();
            $std_activity['std_activity']       = $this->input->post('std_activity',true);
            $std_activity['std_name']           = $this->input->post('std_name',true);

            $this->RegistrationModel->InsertData('student_activity',$std_activity);

            $response['error']=false;
            $response['success']=true;
            $response['msg']="Student Discipline Activity Successfully added";
        }else
        {
            $response['error']=true;
            $response['error_list']=$this->form_validation->error_array();
        }
        echo json_encode($response);
    }


    
    //added by nishi 
    public function incoming_student_detail($std_id){ 
        $condition = ['student_id'=> $std_id];
        $data = array();
        $data['student_id']=$std_id;
        $condition=['acceptance_flag'=> 0];
        $data['incoming_student']=$this->RegistrationModel->get_result('student_info', $condition);
        $data['student_info'] = $this->RegistrationModel->get_row('student_info', $condition);
        $data['content']=$this->load->view('front-end/incomingStudent/incoming_student_detail', $data, true);
        $this->load->view('front-end/master', $data);  
    }


    public function page_1($std_id){

        $condition = ['student_id'=> $std_id];

        $data=array();
        $data['student_info'] = $this->RegistrationModel->get_row('student_info', $condition);
        $data['social_security'] = $this->RegistrationModel->get_row('std_social_security' , $condition);
        $data['appearance'] = $this->RegistrationModel->get_row('std_appearance' , $condition);
        $data['ethnic_background'] = $this->RegistrationModel->get_row('std_ethnic_background' , $condition);
        $data['emergency_contact'] = $this->RegistrationModel->get_row('std_emergency_contact' , $condition);
        $data['reference'] = $this->RegistrationModel->get_row('std_reference' , $condition);
        $data['personality_info'] = $this->RegistrationModel->get_row('std_personality_info' , $condition);
        $this->load->view('front-end/incomingStudent/page1', $data);
    }

    public function page_2($std_id){
        $condition = ['student_id'=> $std_id];

        $data=array();
        $data['family_member'] = $this->RegistrationModel->get_result('std_family_member', $condition);
        $data['std_family_history'] = $this->RegistrationModel->get_row('std_family_history' , $condition);
        $this->load->view('front-end/incomingStudent/page2', $data);
    }

    public function page_3($std_id){
        $condition = ['student_id'=> $std_id];

        $data=array();
        $data['marital_history'] = $this->RegistrationModel->get_row('std_marital_history', $condition);
        $data['children_info'] = $this->RegistrationModel->get_row('std_children_info' , $condition);
        $data['children'] = $this->RegistrationModel->get_result('std_children', $condition);
        $data['abuse_history'] = $this->RegistrationModel->get_row('std_abuse_history' , $condition);
        $data['military_history'] = $this->RegistrationModel->get_row('std_military_history' , $condition);
        $this->load->view('front-end/incomingStudent/page3', $data);
    }

    public function page_4($std_id){
       $condition = ['student_id'=> $std_id];

        $data=array();
        $data['legal_history'] = $this->RegistrationModel->get_row('std_legal_history', $condition);
        $data['crime_history'] = $this->RegistrationModel->get_result('std_crime_history' , $condition);
        $data['in_prison'] = $this->RegistrationModel->get_result('std_in_prison', $condition);
        $data['social_involvement_history'] = $this->RegistrationModel->get_row('std_social_involvement_history' , $condition);
        $this->load->view('front-end/incomingStudent/page4', $data); 
    }

    public function page_5($std_id){
        $condition = ['student_id'=> $std_id];

        $data=array();
        $data['financial_status'] = $this->RegistrationModel->get_row('std_financial_status', $condition);
        $data['academic_info'] = $this->RegistrationModel->get_row('std_academic_info' , $condition);
        $data['training_list'] = $this->RegistrationModel->get_result('std_training_list', $condition);
        $data['std_life_event'] = $this->RegistrationModel->get_row('std_life_event' , $condition);
        $this->load->view('front-end/incomingStudent/page5', $data); 
    }

    public function page_6($std_id){
        $condition = ['student_id'=> $std_id];

        $data=array();
        $data['std_occupational_history'] = $this->RegistrationModel->get_row('std_occupational_history', $condition);
        $data['std_most_recent_job'] = $this->RegistrationModel->get_result('std_most_recent_job' , $condition);
        $data['medical_history'] = $this->RegistrationModel->get_row('std_medical_history', $condition);
        $this->load->view('front-end/incomingStudent/page6', $data);   
    }
    
    public function page_7($std_id){
        $condition = ['student_id'=> $std_id];

        $data=array();
        $data['medical_history'] = $this->RegistrationModel->get_row('std_medical_history', $condition);
        $data['spiritual_history'] = $this->RegistrationModel->get_row('std_spiritual_history' , $condition);
        $data['drug_history'] = $this->RegistrationModel->get_row('std_drug_history' , $condition);
        $data['physicial_info'] = $this->RegistrationModel->get_row('std_physicial_info', $condition);
        $this->load->view('front-end/incomingStudent/page7', $data);   
    }
    
    public function page_8($std_id){
        $condition = ['student_id'=> $std_id];

        $data=array();
        $data['problem_definition'] = $this->RegistrationModel->get_row('std_problem_definition', $condition);
        $this->load->view('front-end/incomingStudent/page8', $data);   
    }

  public function activate_student($std_id){
      
       $data=array();
       $data['acceptance_flag']=1;
       $data['status']=1;
       $data['acceptance_date']=date("Y/m/d");
       $this->db->where('student_id', $std_id)->update('student_info', $data);
       redirect('student_manager');
    }
	//added by AA ---------------


}
