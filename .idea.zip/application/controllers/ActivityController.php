<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ActivityController extends CI_Controller {
   
    public function __construct()
    {
	    parent::__construct();
	    $this->load->library('form_validation');
        $this->load->model(['ActivityModel']);
        $this->load->library('ion_auth');
        $this->load->helper('language');
        $this->lang->load('auth');

        if (!$this->ion_auth->logged_in())
        {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
    }
    
    public function activity($id)
    {
        $data = array();
        $data['student_id']=$id;
        $data['tags'] = $this->db->query("SELECT * FROM `personnel`")->result();
        $data['all_activity_data'] = $this->db->query("SELECT * FROM `activity_log` ORDER BY `id` DESC")->result();
        $data['content']=$this->load->view('front-end/record/activity-log',$data,true);
        $this->load->view('front-end/master', $data);
    } 
    //get data method
    public function get_data()
    {
 
        $student_activity = $this->db->query('SELECT * FROM `activity_log` ORDER BY `id` DESC')->result();
        $html = '';

        foreach($student_activity as $activity){
            $html .= '<div class="activity-content">';
            $html .= '<p><span>'.date('D',strtotime($activity->activity_date));
            $html .= '</span> <span>'.date('d/m/Y',strtotime($activity->activity_date)); 
            
            $html .= '</span> at <span>';
            $html .= date('h:i A',strtotime($activity->activity_date));
            
            $html .='</span> by <span>'.$activity->author.'</span></p>';
            $html .= '<p>'.$activity->activity.'</p>';
            $html .= '<p>Tags:';
            
            $tag_id = $this->db->query("SELECT * FROM `activity_tag` WHERE `activity_id`='".$activity->id."'")->result();
                foreach($tag_id as $value){
                   $tag_name = $this->db->query("SELECT * FROM `personnel` WHERE `id`='".$value->tag."'")->result();
                        foreach($tag_name as $tag){
                            $html .= '<a href="'.base_url('/personnel-details/'.$tag->id).'">'.$tag->first_name.'  '.$tag->last_name.' , '.'</a>';

                     }
                }
            $html .= '</p></div>';
        }
       
        echo json_encode($html);

    }    
    //get filter data method
    public function date_filter()
    {
        $search_date = '%'.date('d-m-Y', strtotime($_POST['src_date'])).'%';
        $student_activity = $this->db->query("SELECT * FROM `activity_log` WHERE `activity_date` LIKE '".$search_date."' ORDER BY `id` DESC")->result();
        $html = '';

        foreach($student_activity as $activity){
            $html .= '<div class="activity-content">';
            $html .= '<p><span>'.date('D',strtotime($activity->activity_date));
            $html .= '</span> <span>'.date('d/m/Y',strtotime($activity->activity_date)); 
            
            $html .= '</span> at <span>';
            $html .= date('h:i A',strtotime($activity->activity_date));
            
            $html .='</span> by <span>'.$activity->author.'</span></p>';
            $html .= '<p>'.$activity->activity.'</p>';
            $html .= '<p>Tags:';
            
            $tag_id = $this->db->query("SELECT * FROM `activity_tag` WHERE `activity_id`='".$activity->id."'")->result();
                foreach($tag_id as $value){
                   $tag_name = $this->db->query("SELECT * FROM `personnel` WHERE `id`='".$value->tag."'")->result();
                        foreach($tag_name as $tag){
                            $html .= '<a href="'.base_url('/personnel-details/'.$tag->id).'">'.$tag->first_name.'  '.$tag->last_name.' , '.'</a>';

                     }
                }
            $html .= '</p></div>';
        }
       
        echo json_encode($html);

    }
               

    public function ActivityLog()
    {
        
        $data = array();
        $data['tags'] = $this->db->query("SELECT * FROM `personnel`")->result();
        $data['all_activity_data'] = $this->ActivityModel->get_result('activity_log');
        $data['content']=$this->load->view('front-end/record/activity-log',$data,true);
        $this->load->view('front-end/master', $data);
    }
    
        public function SaveActivityValue()
    {
        $user = $this->ion_auth->user()->row();
        
        $this->form_validation->set_rules('activity', 'Activity', 'required');
        if (empty($_POST['tags']))
        {
            $this->form_validation->set_rules('tags', 'Tags', 'required');
        }

//        $this->form_validation->set_rules('activity_date', 'Activity Date', 'required');

        $response = array(
            'success'=> false,
            'error'=> false,
            'msg'=>''
        );

        if ($this->form_validation->run() === true) {

            $activity_data=array();
            $activity_data['activity']      = $this->input->post('activity',true);
            $activity_data['activity_date'] = date("d-m-Y h:i:sa");
            $activity_data['author'] = $user->username;
            if ($_POST['student_id'] != '')
            {
                $activity_data['student_id'] = $_POST['student_id'];
            }
            $activity_id = $this->ActivityModel->InsertData('activity_log',$activity_data);
            foreach($_POST['tags'] as $tag){
                $this->db->query("INSERT INTO `activity_tag` (`activity_id`, `tag`) VALUES ($activity_id, $tag)");
            }
            $response['error']=false;
            $response['success']=true;
            $response['msg']="Activity log Successfully added";
        }else
        {
            $response['error']=true;
            $response['error_list']=$this->form_validation->error_array();
        }
        echo json_encode($response);
    }
    
}