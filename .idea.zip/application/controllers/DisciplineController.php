<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DisciplineController extends CI_Controller {
   
    public function __construct()
    {
	    parent::__construct();
	    $this->load->library('form_validation');
        $this->load->model('ChronologicalModel');
        $this->load->library(['ion_auth','pagination']);
        $this->load->helper('language');
        $this->lang->load('auth');

        if (!$this->ion_auth->logged_in())
        {
            // redirect them to the login page
            redirect('auth/login', 'refresh');
        }
    }
    
    public function StudentDiscipline($id = '')
    {
          if($id == ''){
           $data = array();
             
            $this->db->select('*');
            $this->db->from('student_info');
            $this->db->join('std_discipline', 'std_discipline.student_id = student_info.student_id');
            $this->db->group_by('student_info.student_id');
            $query= $this->db->get();
            $data['all_datas'] =  $query->result();
            $data['pending_student'] = $this->db->query("SELECT * FROM `std_discipline` Where `status`=1 ORDER BY `id` DESC")->result();
              
            $data['resolve_discipline'] = $this->db->query("SELECT * FROM `std_discipline` Where `status`=3 ORDER BY `id` DESC")->result();
//            var_dump($data['all_datas']);
           $data['content']=$this->load->view('front-end/record/all_disciplines', $data, true);
            $this->load->view('front-end/master', $data);
            
        } else {
            $data = array();
              $data['student_id'] = $id;
            $data['students'] = $this->db->query('SELECT * FROM `student_info` WHERE `status`=1')->result();
        
            $data['content']=$this->load->view('front-end/record/student-discipline', $data, true);
        $this->load->view('front-end/master', $data);       
        }
        
    }
    //store method
    public function store()
    {
         $this->form_validation->set_rules('discipline_des', 'Entry Description', 'required');
        $response = array(
            'success'=> false,
            'error'=> false,
            'msg'=>''
        );

        if ($this->form_validation->run() === true) {

            $std_entry=array();
            $std_entry['discipline_des']  = $this->input->post('discipline_des',true);
   
         
            $std_entry['created_at'] = date("d-m-Y h:i:sa");
            $std_entry['student_id'] = $_POST['student_id'];
            
            $this->ChronologicalModel->InsertData('std_discipline',$std_entry);

            $response['error']=false;
            $response['success']=true;
            $response['msg']="Discipline Added Successfully!";
        }else
        {
            $response['error']=true;
            $response['error_list']=$this->form_validation->error_array();
        }
        echo json_encode($response);
    }
    
    public function disciplineDetails($id){
         $data=array();
         $this->db->select('*');
        $this->db->from('std_discipline');
        $this->db->where('student_id',$id);
        $query= $this->db->get();
        $data['std_discipline'] =  $query->result();
        

//        $config['total_rows'] = count($data['std_discipline']);
//        $config['per_page'] = 1;
//
//        $this->pagination->initialize($config);

        $data['content']=$this->load->view('front-end/record/discipline_details', $data, true);
        $this->load->view('front-end/master', $data);
    }
}