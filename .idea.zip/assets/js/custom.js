//form validations
$('#submit_form_1').click(function () {
    if (document.forms["reg_form1"]["first_name"].value == "") {
      $('.first_name').text('The first name field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["last_name"].value == "") {
      $('.last_name').text('The last name field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["address_line1"].value == "") {
      $('.address_line1').text('The address line 1 field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["city"].value == "") {
      $('.city').text('The city field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["state"].value == "") {
      $('.state').text('The state field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["zip_code"].value == "") {
      $('.zip_code').text('The zip field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["home_phone"].value == "") {
      $('.home_phone').text('The home phone field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["social_security_number"].value == "") {
      $('.social_security_number').text('The social security number field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["date_of_birth"].value == "") {
      $('.date_of_birth').text('The date of birth field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["ethnic_background"].value == "") {
      $('.ethnic_background').text('The ethnic background field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["emc_name"].value == "") {
      $('.emc_name').text('The name field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["emc_address_line1"].value == "") {
      $('.emc_address_line1').text('The address line 1 field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["emc_city"].value == "") {
      $('.emc_city').text('The city field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["emc_state"].value == "") {
      $('.emc_state').text('The state field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["emc_zip_code"].value == "") {
      $('.emc_zip_code').text('The zip field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["emc_home_phone"].value == "") {
      $('.emc_home_phone').text('The home phone field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["emc_relation_to_student"].value == "") {
      $('.emc_relation_to_student').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["is_expressive"].value == "") {
      $('.is_expressive').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["explanation_is_expressive"].value == "") {
      $('.explanation_is_expressive').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["is_rational"].value == "") {
      $('.is_rational').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form1"]["explanation_is_rational"].value == "") {
      $('.explanation_is_rational').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
});

    
$('#submit_form_2').click(function () {
    if (document.forms["reg_form2"]["relationship_as_child"].value == "") {
        $('.relationship_as_child').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["relationship_at_present"].value == "") {
        $('.relationship_at_present').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["fathers_name"].value == "") {
        $('.fathers_name').text('The fathers name field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["mothers_name"].value == "") {
        $('.mothers_name').text('The mothers name field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["is_father_living"].value == "") {
        $('.is_father_living').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["is_mother_living"].value == "") {
        $('.is_mother_living').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["parents_marital_status"].value == "") {
        $('.parents_marital_status').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["childhood_rating"].value == "") {
        $('.childhood_rating').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["childhood_rating_reason"].value == "") {
        $('.childhood_rating_reason').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["not_feel_closest"].value == "") {
        $('.not_feel_closest').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["last_seen_parents"].value == "") {
        $('.last_seen_parents').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["last_live_at_home"].value == "") {
        $('.last_live_at_home').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form2"]["is_adopted"].value == "") {
        $('.is_adopted').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
   //family member validation is pending...
});



$('#submit_form_3').click(function () {
    if (document.forms["reg_form3"]["current_marital_status"].value == "") {
        $('.current_marital_status').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    //living_arrangement is pendig
    
    if (document.forms["reg_form3"]["have_children"].value == "") {
        $('.have_children').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form3"]["is_abused"].value == "") {
        $('.is_abused').text('The field is required').css({"color": "red", "font-weight": "500"});
    }

    //sexual lifecycle is pending

    if (document.forms["reg_form3"]["is_engaged_homosexual"].value == "") {
        $('.is_engaged_homosexual').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form3"]["how_recently_involved"].value == "") {
        $('.how_recently_involved').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form3"]["current_spouse_state"].value == "") {
        $('.current_spouse_state').text('The state field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form3"]["current_spouse_zip_code"].value == "") {
        $('.current_spouse_zip_code').text('The zip field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form3"]["current_spouse_home_phone"].value == "") {
        $('.current_spouse_home_phone').text('The  home phone field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form3"]["is_served_us_army"].value == "") {
        $('.is_served_us_army').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
});
    


$('#submit_form_4').click(function () {
    if (document.forms["reg_form4"]["teen_challenge_accepted"].value == "") {
        $('.teen_challenge_accepted').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form4"]["ul_supervision"].value == "") {
        $('.ul_supervision').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    // if (document.forms["reg_form4"]["pending_against"].value == "") {
    //     $('.pending_against').text('The field is required').css({"color": "red", "font-weight": "500"});
    // }
    if (document.forms["reg_form4"]["arrested_value"].value == "") {
        $('.arrested_value').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form4"]["in_prison"].value == "") {
        $('.in_prison').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form4"]["religion"].value == "") {
        $('.religion').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form4"]["sports"].value == "") {
        $('.sports').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form4"]["peer_group"].value == "") {
        $('.peer_group').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form4"]["community_affiliation"].value == "") {
        $('.community_affiliation').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form4"]["hobbies"].value == "") {
        $('.hobbies').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form4"]["other"].value == "") {
        $('.other').text('The field is required').css({"color": "red", "font-weight": "500"});
    }

});



$('#submit_form_5').click(function () {
    if (document.forms["reg_form5"]["have_applied_food_stamp"].value == "") {
        $('.have_applied_food_stamp').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["movies"].value == "") {
        $('.movies').text('The movies field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["losses"].value == "") {
        $('.losses').text('The losses field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["sexual_abuse"].value == "") {
        $('.sexual_abuse').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["physical_abuse"].value == "") {
        $('.physical_abuse').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["home_placement"].value == "") {
        $('.home_placement').text('The home placement is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["cultural_influence"].value == "") {
        $('.cultural_influence').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["other_event"].value == "") {
        $('.other_event').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["highest_grade"].value == "") {
        $('.highest_grade').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["can_read"].value == "") {
        $('.can_read').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["reading_competency"].value == "") {
        $('.reading_competency').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["can_write"].value == "") {
        $('.can_write').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["writing_competency"].value == "") {
        $('.writing_competency').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form5"]["have_vocational_training"].value == "") {
        $('.have_vocational_training').text('The field is required').css({"color": "red", "font-weight": "500"});
    }

});


$('#submit_form_6').click(function () {
    if (document.forms["reg_form6"]["profession"].value == "") {
        $('.profession').text('The profession field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form6"]["jobs_last_two_years"].value == "") {
        $('.jobs_last_two_years').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form6"]["present_employement_status"].value == "") {
        $('.present_employement_status').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    // if (document.forms["reg_form6"]["have_diet_requirement"].value == "") {
    //     $('.have_diet_requirement').text('The field is required').css({"color": "red", "font-weight": "500"});
    // }
});


$('#submit_form_7').click(function () {
    if (document.forms["reg_form7"]["packs_of_cigarette"].value == "") {
        $('.packs_of_cigarette').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["cups_of_coffee"].value == "") {
        $('.cups_of_coffee').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["cups_of_tea"].value == "") {
        $('.cups_of_tea').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["use_alcohol"].value == "") {
        $('.use_alcohol').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["use_amphetamines"].value == "") {
        $('.use_amphetamines').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["use_heroin"].value == "") {
        $('.use_heroin').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["use_opium"].value == "") {
        $('.use_opium').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["use_cocaine"].value == "") {
        $('.use_cocaine').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["use_marijuana"].value == "") {
        $('.use_marijuana').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["use_crack"].value == "") {
        $('.use_crack').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["use_crank"].value == "") {
        $('.use_crank').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["have_born_again"].value == "") {
        $('.have_born_again').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["circumstances"].value == "") {
        $('.circumstances').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["current_spiritual_condition"].value == "") {
        $('.current_spiritual_condition').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["attend_charch"].value == "") {
        $('.attend_charch').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["is_member_of_charch"].value == "") {
        $('.is_member_of_charch').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["attend_charch_as_child"].value == "") {
        $('.attend_charch_as_child').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["do_believe_god"].value == "") {
        $('.do_believe_god').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["do_pray"].value == "") {
        $('.do_pray').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["read_bibel"].value == "") {
        $('.read_bibel').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["read_other"].value == "") {
        $('.read_other').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["recent_change_in_rl"].value == "") {
        $('.recent_change_in_rl').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form7"]["explanation"].value == "") {
        $('.explanation').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    // if (document.forms["reg_form7"]["involved_in_cults"].value == "") {
    //     $('.involved_in_cults').text('The field is required').css({"color": "red", "font-weight": "500"});
    // }
    // //involved_in_cults is pending

});




$('#submit_form_8').click(function () {
    if (document.forms["reg_form8"]["main_problem"].value == "") {
        $('.main_problem').text('The main problem field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form8"]["what_done_about_main_problem"].value == "") {
        $('.what_done_about_main_problem').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form8"]["greatest_needs"].value == "") {
        $('.greatest_needs').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    if (document.forms["reg_form8"]["is_in_program_before"].value == "") {
        $('.is_in_program_before').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
    //problem_type is pending
    if (document.forms["reg_form8"]["programs_been_in_before"].value == "") {
        $('.programs_been_in_before').text('The field is required').css({"color": "red", "font-weight": "500"});
    }
});